# -*- coding: euc-kr -*-

### runtime�� ��������ʴ� UI��������� ��������

## simulation flag for Call related self-testing. 
sim_mode_flag = False          #This value must be False when package is released.
sim_msg_generate_flag = False  #This value must be False when package is released.
relese_connected_accept_incoming_flag = True # for testing the access code A4 

# debugging flag
if sim_mode_flag == False:
	vdcimsg_debug = False   # display request and receive message with VDCI
	key_debug = False		# display key events
	stage_debug = False	    # display current stage
	dspg_debug = False      # display messages to control dspg.
	ring_debug = False 
	audio_debug = False	
	dtmf_debug = False
	sms_debug = False
	calllog_debug = False
	utils_debug = False
	sim_debug = False
	sim_reader_debug = False 
	sac3_debug = False
	modem_debug = False
	mm_debug = False
	videocall_debug = False
	memorystatus_debug = False
	detail_debug = False
	log_debug = False         # for config.log_file 
	settingsave_debug = False # setting_save.py : saved in every 60sec and when changed.
	screensaver_debug = False
	phonebook_debug = False
	phonedb_debug = False
	timer_debug = False
	vdcitone_debug = False    # for debugging dial,busy tone play
	pppsetup_debug = False	  # for debugging setup-ppp
	critical_debug = False
	alarm_debug = False
	sdmmc_debug = False
	memfull_debug = False
	aptcp_debug = False
	mms_debug = False
	richtext_debug = False
else:
	vdcimsg_debug = True
	key_debug = True 
	stage_debug = True
	dspg_debug = True
	ring_debug = True 
	audio_debug = True 
	dtmf_debug = True
	sms_debug = True
	calllog_debug = True
	utils_debug = True
	sim_debug = True
	sim_reader_debug = True 
	sac3_debug = True
	modem_debug = False
	mm_debug = True
	videocall_debug = True
	memorystatus_debug = True
	detail_debug = True
	log_debug = False 
	settingsave_debug = False	 
	screensaver_debug = True
	phonebook_debug = True
	phonedb_debug = True
	timer_debug = True
	vdcitone_debug = True	   
	pppsetup_debug = True
	critical_debug = True
	alarm_debug = True
	sdmmc_debug = True
	memfull_debug = True
	aptcp_debug = False
	mms_debug = True
	richtext_debug = True
## key events
Menu1 = 'F1'
Menu2 = 'F2'
LongMenu2 = 'F2 Long'
OnHook = 'F3'
OffHook = 'F4'
Green = 'F5'
Red = 'F6'
Video = 'F7'
VideoPrivacy = 'F8'
Snapshot = 'F9'
VideoSize = 'F10'
ASTERISK_4 = '4*'
key_link_up = 'LINKUP'
key_link_down = 'LINKDOWN'	 

start_with_offhook = True
i_am_ppp_server = False

x=0
y=0
width = 320
height = 240
rotation = 0
	
# PRO SERVICE CODE
RECALL_CODE = '5'
FLASHR_CODE = 'R'
R1_CODE = 'R1'
R2_CODE = 'R2'
R3_CODE = 'R3'
MA_CODE 	= 'A1'
AC1_CODE	= 'A2'
AC2_CODE	= 'A3'
AC3_CODE	= 'A4'
RO_CODE 	= 'A5'
DI1_CODE 	= 'B2'
DI2_CODE 	= 'B3'
DB1_CODE 	= 'B4'
DB2_CODE 	= 'B5'
DNR1_CODE 	= 'B6'
DNR2_CODE 	= 'B7'
CO_CODE 	= 'C1'
VM1_CODE 	= 'D1'
VM2_CODE 	= 'D2'
CL1_CODE 	= 'D3'
CL2_CODE 	= 'D4'
CBO1_CODE	= 'C2'
CBO2_CODE	= 'C3'
CBO3_CODE	= 'C4'

# TEST CODE
#MA_CODE 	= '13'
#AC1_CODE	= '14'
#AC2_CODE	= '156'
#AC3_CODE	= '10*#'
#RO_CODE 	= '2345'
#DI1_CODE 	= '19'
#DI2_CODE 	= '24'
#DB1_CODE 	= '25'
#DB2_CODE 	= '26'
#DNR1_CODE 	= '27'
#DNR2_CODE 	= '28'
#CO_CODE 	= '29'
#VM1_CODE 	= '33'
#VM2_CODE 	= '34'
#CL1_CODE 	= '35'
#CL2_CODE 	= '36'

ENDCONF_CODE = AC2_CODE
ENDCALL_CODE = AC3_CODE
ACCEPT_CODE = AC1_CODE
REJECT_CODE = AC3_CODE

# file path
var_path='/usr/local/lgvp/var/'
log_file=var_path + 'log'
module_file=var_path + 'module.info'
product_model_file=var_path + 'product_model.info'

# modem setting
#modem_patch = ('Patch_EIS_2C_0E_RAM-ike_02_LGE3_2.ptc', )
#modem_patch = ('Patch_EIS_2C_12_RAM-ike_02_LGE3_2.ptc', )
#modem_patch = ('Patch_EIS_2C_12_RAM-ike_02_LGE3_2LockUpFixRobustQC_1.ptc', )
#modem_patch = ('Patch_EIS_2C_14_RAM-ike_02_LGE3_3.ptc', )
#modem_patch = ('Patch_EIS_2C_1D_RAM-ike_02_3_3.ptc', )
modem_patch = ('Patch_EIS_2C_3A_RAM-ike_02_LGE3.7.ptc', )

# for PCM UPSTREAM
#modem_patch = ('Patch_EIS_2C_2C_RAM-ike_02_LGE3.5.ptc', )

# db size
if sim_mode_flag == False:
	performed_db_size = 20
	dialed_db_size = 20
	missed_db_size = 20
	received_db_size = 20
	phone_db_size = 300
else:
	performed_db_size = 20	
	dialed_db_size = 20
	missed_db_size = 20
	received_db_size = 20
	phone_db_size = 10

# Sound Input Sample Rate
# 0: default
# set this value to 8000 when we get exact rate
sound_source_rate = 0

# 
hidden_number_prefix = '*67#'


# �ִ� ����� ���� �ð�
audio_record_duration = 20

# �ִ� ���� ���� �ð�
video_record_duration = 300
video_record_duration_for_mms = 20

# �ּ� ���� �������(�׻� �̸�ŭ�� free �� �����ϰԲ�) : KB
# update �� ���� 4000, ������ free space 500
#    modified (3/10): 4500--> 5000, 5500 --> 6000
min_free_storage = 5000 	# short.. 
nearly_free_storage = 6000	# warning.. < 1MB

# message db files
sms_received_path = 'messages/sms/received/'
sms_saved_path = 'messages/sms/saved/'
sms_personal_info = 'messages/sms/personal.info'
sms_received_info = 'messages/sms/received.info'

mms_received_path = 'messages/mms/received/'
mms_saved_path = 'messages/mms/saved/'
mms_personal_info = 'messages/mms/personal.info'
mms_received_info = 'messages/mms/received.info'

email_saved_path = 'messages/email/saved/'
email_personal_info = 'messages/email/personal.info'

fax_saved_path = 'messages/fax/saved/'
fax_personal_info = 'messages/fax/personal.info'

# max
sms_max = 612
email_max = 109
fax_max = 110
mms_subject_max = 40
mms_text_max = 2000

# max size of attached file for MMS : KB
mms_size_max = 100
# min size of video that can be inserted to mms message
min_video_size = 10

mms_tmp_video_clip_dir = '/tmp/video_clip/'
# media type for MMS
media_text = 1001
media_image = 1002
media_sound = 1003
media_video = 1004

# message�� ����Ǵ� ���丮
message_dir = 'messages/'

# temporary save path for MMS object
mms_temp_message_path = '/tmp/tempmessage/'
mms_temp_message_thumb_path = '/tmp/tempmessage/thumb/'
gif_tempdir = '/tmp/tmp_gif/'

# mmsc �ּ�
mmsurl = 'http://mmsc1-clu-cz.mmsc.drtes.telecomitalia.it/mms'
asdomain_mms = 'http://sipgw1-clu-cz.telecomitalia.it'

# mmsc port
mmscport = 3128
asport_mms = 8012

# mms notification port
mms_noti_dest_port = 2948
mms_noti_orig_port = 9200

# bg�� �⺻ �����Ǵ� ���ϵ�
bg_lists = 'CASE.png', 'FULMINE.png', 'TERRA.png', 'CASE.png', 'TOSCANA.png'

# image��  ����Ǵ� ���丮
image_bg_dir = 'photos/bg/'

# background �� ���õ� bg �� ����Ǽ� ����Ǵ� ���丮
image_background_dir = 'photos/background/'

def_bg = image_bg_dir + 'TERRA.png'

# mms�� ���� ���� �̹���
image_wallpaper_dir = 'photos/wallpaper/'
# sms�� ���� ���� �̹���
image_picture_dir = 'photos/picture/'
image_taken_dir = 'photos/taken/'
image_snapshot_dir = 'photos/snapshot/'
# audio�� ����Ǵ� ���丮
audio_def_dir = 'audios/ring/'
# ���� ���ڵ�� ����
audio_recorded_dir = 'audios/recorded/'
# mms�� ���� ���� poly midi
audio_polyphonic_dir = 'audios/polyphonic/'
# sms�� ���ع��� ringtone
audio_other_dir = 'audios/other/'
# message voice files directory
audio_message_dir = 'audios/messages/'

alarm_melody = audio_def_dir + '006_Dance - Mambo.wav'

wait_melody = 'audios/wait/waiting.wav'
wait_melody_in_IP_profile = '/usr/local/lgvp/audios/wait/waiting.wav'

dial_tone_melody = 'audios/wait/dial_ulaw.wav'
ringback_tone_melody = 'audios/wait/ringback_ulaw.wav'
busy_tone_melody = 'audios/wait/busy_ulaw.wav'
cg_tone_melody = 'audios/wait/cg_ulaw.wav'

# default ring file
def_melody = audio_def_dir + '010_Happy moment 1.wav'
for_one_ring_melody = audio_def_dir + '023_Standard ring 6.wav'

# for sms ring
sms_ring = 'audios/wait/dingdong.wav'

# ������(jwoo) : for camera shutter
cam_shutter = 'audios/effect/camshutter.wav'

# video�� ����Ǵ� ���丮
video_recorded_dir = 'videos/recorded/'
video_recorded_thumb_dir = 'videos/recorded/thumb/'
video_received_dir = 'videos/received/'
video_received_thumb_dir = 'videos/received/thumb/'

#image_rcvd_dir = 'photos/received/'
# sdmmc src/dst directory by shchun
sdmmc_root_dir = '/usr/mmchd/'

image_dst_taken_dir =   sdmmc_root_dir + 'Taken photos/'
image_dst_taken_dir_it =   sdmmc_root_dir + 'Foto scattate/'

image_dst_picture_dir = sdmmc_root_dir + 'Pictures/'
image_dst_picture_dir_it = sdmmc_root_dir + 'Loghi&Disegni/'

image_dst_wallpaper_dir = sdmmc_root_dir + 'Wallpapers/'
image_dst_wallpaper_dir_it = sdmmc_root_dir + 'Foto&Immagini/'

image_dst_bg_dir =      sdmmc_root_dir + 'Videophone\'s images/'
image_dst_bg_dir_it =      sdmmc_root_dir + 'Immagini Videotelefono/'

image_dst_recvd_dir =   sdmmc_root_dir + 'Received images/'
image_dst_recvd_dir_it =   sdmmc_root_dir + 'Immagini recevute/'
 
image_dst_all_dir =     sdmmc_root_dir + 'Images/'
image_dst_all_dir_it =     sdmmc_root_dir + 'Immagini/'

sound_dst_recorded_dir = sdmmc_root_dir + 'Recorded audios/'
sound_dst_recorded_dir_it = sdmmc_root_dir + 'Audio registrati/'

sound_dst_ring_dir =     sdmmc_root_dir + 'Videophone\'s melodies/'
sound_dst_ring_dir_it =     sdmmc_root_dir + 'Melodie Videotelefono/'

sound_dst_poly_dir =     sdmmc_root_dir + 'Polyphonic melodies/'
sound_dst_poly_dir_it =     sdmmc_root_dir + 'Melodie polifoniche/'

sound_dst_other_dir =    sdmmc_root_dir + 'Other melodies/'
sound_dst_other_dir_it =    sdmmc_root_dir + 'Altre Melodie/'

sound_dst_all_dir =      sdmmc_root_dir + 'Sounds/'
sound_dst_all_dir_it =      sdmmc_root_dir + 'Suoni/'

sound_dst_rcvd_dir =     sdmmc_root_dir + 'Received melodies/'
sound_dst_rcvd_dir_it =     sdmmc_root_dir + 'Melodie ricevute/'

video_dst_recorded_dir = sdmmc_root_dir + 'Recorded videos/'
video_dst_recorded_dir_it = sdmmc_root_dir + 'Video registrati/'

video_dst_rcvd_dir =     sdmmc_root_dir + 'Received videos/'
video_dst_rcvd_dir_it =     sdmmc_root_dir + 'Video ricevuti/'

video_dst_all_dir =      sdmmc_root_dir + 'Videos/'
video_dst_all_dir_it =      sdmmc_root_dir + 'Video/'

all_dst_all_dir =      sdmmc_root_dir + 'Videophone contents/'
all_dst_all_dir_it =      sdmmc_root_dir + 'Contenuti Videotelefono/'

sdmmc_copy_interval = 500

image_import_dir = image_wallpaper_dir
image_import_picture_dir = image_picture_dir
sound_import_dir = audio_polyphonic_dir
sound_import_mono_dir = audio_other_dir
video_import_dir = video_received_dir

UNLIMIT_MAX=9999

# LIMIT MAX
#image_import_max = 10
#sound_import_max = 10
#video_import_max = 10

# UNLIMIT MAX
image_import_max = UNLIMIT_MAX
sound_import_max = UNLIMIT_MAX
video_import_max = UNLIMIT_MAX

copy_sim_interval = 10

# When file import, maximum size of file (in Kb)
# change 500 --> 10 Mega : TI ��û
max_import_size = 10000   
max_import_x = 640
max_import_y = 480

# PIN ���� �ִ� ����
len_pin_number = 4

# setting�� ����Ǵ� ���� : 60sec �������� setting._�� ���۵Ǵ� parameters�� �����.
setting_file = 'setting_save.py'
vdcisetting_file = 'vdci.cfg'

# socket path for communicate with VDCIApp
vdci_socket_path = '/tmp/vdcisock'

### Timer value
timerT1 = 15000
timerT2 = 5000
timerT3 = 0 # new value for Type Approval, timerT3 = 1000	original value
timerT3_1 = 500
timerT3_2 = 1000
timerT4 = 300  # 300->5000 not used.??
# timerT4_1 must bigger than 1500ms, because modem delay is too long (about 1500ms)
# if timerT4_1 = 1200, real delay would be about 1300~1500ms
timerCloseModem = 0 	# sec
timerT4_1 = timerCloseModem*1000+1500
# timerT4_2 is not used, because DTMF outgoing timer is included in modem initial code (ATS6)
# ex. modem_init3 = "ATS6=4;+IBC=0;+MR=1\r"
timerT4_2 = 4000
#timerT5 = 30000 
timerT5_1 = 70000 
timerT5_2 = 30000 
# due to v.92 problem, modify T5 from 20 to 30 seconds 20050715.xls
timerT6 = 1000
timerT11=2000 # 0314 - SAC3ȣ�� 2�� �� ����
#timerTxx = 80000 # defined by hypark. refer to Combo Spec 70 sec(hangup<->ServerCall)

if sim_mode_flag == False:	
	ring_timeout = 7000          # timer to wait next ring after receiving a ring
	cid_wait_timeout = 2000    # this timer is runned when receiving a first ring
	stop_ring_timer = 181000  # incoming call become missed call after this timer is expired.
	timerSetTime = 60*1000   # interval for updating to setting_save.py
	timerDelayInvite = 300	    # orginal value =300, but 5300 in our NAS Server
	timeoutInvite = 60000	    # caller : run this timer after sending request message
else:	
	ring_timeout = 7000
	cid_wait_timeout = 500
	stop_ring_timer = 18000
	timerSetTime = 10*60*1000 
	timerDelayInvite = 5300    # orginal value =300, but 5300 in our NAS Server
	timeoutInvite = 60000
	
timerPPPfail = 60000
timerRunVDCIApp = 2000
timerRegister = 30000           # waiting register-server-msg(PSTN)
timerWaitRegMSG = 60000    # waiting register-server-msg(IP)
timerSnapshot = 3000
timerResize = 300
timeoutRegister = 30000  # unused until now

onhook_interval = 500     # on/off hook
long_key_interval = 2 * 1000 # Long Key�� ���ֵǴ� �ð� ����		
# call -> connect�� �Ѿ�� �ð� delay
# �� �ð��� �������� ����� �Է��� ������ ��ȭ�� �ɸ������� ����
connect_delay = 200 #5 * 1000
ring_cycle = 4000 # incomingcall parameter

# DTMF for video call handshake
videocall_request_dtmf = 'C'
videocall_answer_dtmf = 'A'

# modem recover counter
modem_recover_counter = 1
modem_check_counter = 3

# interval of getting fps
timerGetFPS = 3000

# Expecting time until video call connected
videocall_time = \
		(0,		# start value
		 30,		# nas handshaking value
		 3,		# ppp negotiation value
		 3,		# register value
		 8,		# invite value
		 3)		# join value
videocall_total_time = 0
for i in videocall_time:
	videocall_total_time += i     # current value : 47sec

# videocall progress' automatically incresing value while no request
videocall_max_auto_increment = 4
videocall_auto_increment_timer = 5000

## IP videocall connecting values
IP_videocall_total_time = 47   # for IP<-->PSTN interoperability
IP_videocall_max_auto_increment = 46
IP_videocall_auto_increment_timer = 1000


# automata ����
#automata_list = [
#	('t9', 'first capital'), ('t9', 'upper'), ('t9', 'lower'),
#	('multitap', 'first capital'), ('multitap', 'upper'), ('multitap', 'lower'),
#	('123', 0)
#]
automata_list = [
	('t9', 'lower'), ('t9', 'first capital'), ('t9', 'upper'),
	('multitap', 'lower'), ('multitap', 'first capital'), ('multitap', 'upper'),
	('123', 0), ('i123', 0)
]

automata_list2 = [
	('multitap', 'upper'), 
	('multitap', 'lower'),
	('123', 0)
]

# T9
t9_word_list = 'var/t9.wordlist'
t9_word_list_max = 1024 * 1024

number_plan_file = 'number_plan.txt'

# SAC3
enable_sac3=True

# replied DTMF of SAC3 call
XY1='00'
XY2='01'
XY3='02'
XY4='03'
XY5='04'
XY6='05'

# 240 hour
min=60*1000
initial_sac3_range=1*60*1000, 10*60*1000
initial_sac3_timer=2000
sac3_interval=240*60*60
#sac3_timeout=30*1000
sac3_timeout=8*1000

timerT11=2000

enable_sac4_timer8 = True
timer8 = 60*min

def read_sac_conf():
	global sac1, sac2, sac3, sac4, sac5
	sac_file = 'sac.cfg'

	for l in open(sac_file):
		if l.find('#') >= 0:
			l = l[:l.find('#')]
		l = l.strip()
		if not l:
			continue
		
		var_name, value = [t.strip() for t in l.split('=', 2)]
		if var_name == 'SAC1':
			sac1 = value
		elif var_name == 'SAC2':
			sac2 = value
		elif var_name == 'SAC3':
			sac3 = value
		elif var_name == 'SAC4':
			sac4 = value
		elif var_name == 'SAC5':
			sac5 = value

read_sac_conf()


# sms ���۽� data���̿� gabage�� �������� ��Ÿ���� ��
# �� ���� False�� ��� ������ �߸��� message�� ���� ������ �����ϰ�
# Error�� �����ش�. True�� ��� valid�� message type�� �ö�����
# �д´�.
sms_ignore_gabage = False

def get_predefined_animation(id):
	return 'photos/predefined/Picture0.sbm'

def get_predefined_melody(id):
	return 'audios/predefined/Song0.imy'

# SMS/FAX/Email �� ���� �ִ� ����
# LIMIT MAX
#message_entry_max = 50

# UNLIMIT MAX
message_entry_max = UNLIMIT_MAX

# LIMIT MAX
# mmtools ���� �ִ� ����
#if sim_mode_flag == False:
#	snap_shot_max = 15
#	video_record_max = 10
#	audio_record_max = 10
#else:
#	snap_shot_max = 5
#	video_record_max = 5
#	audio_record_max = 5
#down_picture_save_max = 20
#down_melody_save_max = 10
#down_video_save_max = 10

# UNLIMIT MAX
snap_shot_max = UNLIMIT_MAX
video_record_max = UNLIMIT_MAX
audio_record_max = UNLIMIT_MAX
down_picture_save_max = UNLIMIT_MAX
down_melody_save_max = UNLIMIT_MAX
down_video_save_max = UNLIMIT_MAX

# offhook�� ���Ŀ� dtmf�� �������ϴ���
dial_wait_time = 2000
dtmf_call_time = 4000

MESG_OUTGOING_CALL = 'c'   #unused
MESG_INCOMING_CALL = 'i'    #unused
#MESG_CALL_VIDEO = 'v'
#MESG_CALL_SETTING = 's'

MESG_PLAY_TONE = 't'
PLAY_DIAL_TONE = 'DIAL'
PLAY_RINGBACK_TONE = 'RINGBACK'
PLAY_BUSY_TONE = 'BUSY'
PLAY_CG_TONE = 'CG'

# video call mesg types
MESG_STARTUP = 's'
MESG_INITIALIZE = 'z'
MESG_REGISTER = 'r'
MESG_UNREGISTER = 'j' # added by hypark at 20060116
MESG_OFFHOOK = 'l'      # added by hypark at 20060511
MESG_CALL = 'c'
MESG_RINGSTOP = 'g'     # added by hypark at 20060116
MESG_CALL_ACCEPT = 'a'
MESG_CALL_REJECT = 'r' # used but not runned.
MESG_CALL_REINVITE = 'v'
MESG_VIDEO_START = 'y' # indicate videocall start to VDCIApp in callee
MESG_DTMF = 'b'
MESG_SET_AUDIO_MUTE = 'k'
MESG_SET_VIDEO_MUTE = 'm'
MESG_GET_INFO = 'i'
MESG_HANGUP = 'h'
MESG_QUIT = 'q'   # PSTN only, �� �޼����� VDCIApp�� �����ϰ� �ʱ�ȭ�Ѵٰ���.
MESG_SET_DIMENSION = 'd'
MESG_SET_SHARPNESS = 'f'    #video fluency
MESG_GET_SNAPSHOT = 't'
MESG_START_WAITING_MUSIC = 'w'
MESG_STOP_WAITING_MUSIC = 'n'

MESG_SET_VOLUME = 'v'          #return message �ʿ�???
MESG_REMOTE_LEAVE = 'l'       #unused
MESG_UNKNOWN = 'u'               

MESG_SEND_MESSAGE = 'p'

MESG_SET_DEBUG = '!'

MESG_ERROR = 'e'
MESG_NOERROR = 'o'


# video call Server message indicator
MESG_SERVER_NOERROR = 'S'
MESG_SERVER_ERROR = 'E'
# video call Server message made with SUCCESS and FAIL
MESG_SERVER_KILLED = 'K'
MESG_SERVER_REGISTER = 'R'
MESG_SERVER_UNREGISTER = 'J'
MESG_SERVER_CALL = 'C'
MESG_SERVER_RINGING = 'G'
MESG_SERVER_HANGUP = 'H'
MESG_SERVER_DTMF = 'D'
MESG_SERVER_INCOMING = 'W'

MESG_SERVER_SNMP_CALLER = 'I'
MESG_SERVER_LOG_DATA = 'O'
MESG_SERVER_UPDATE = 'U'

MESG_SERVER_MESSAGE_IN = 'F'
MESG_SERVER_SEND_MESSAGE = 'P'

MESG_CONSOLE_DBG = '!'
MESG_FILE_DBG = '@'
MESG_MMI_STATUS = '&'
MESG_MESSAGE_RESULT = '$'
MESG_PLAY_SOUND = '%'

# video call information message
INFO_FPS = '0'  #FPS : Frame per Second
INFO_VOL = '1'
INFO_MBW = '2'
INFO_CBW = '3'
INFO_MTU = '4'

# iSMS/iMMS
# MESSAGE type
INFO_SMS = 1
INFO_MMS = 2

INFO_SMS_ENCODING = 'base64'
INFO_SMS_TYPE = 'application'
INFO_SMS_SUBTYPE = 'vnd.3gpp.sms-tl'

INFO_MMS_TYPE = 'text'
INFO_MMS_SUBTYPE = 'plain'

AUTODETECT=False

modem_init_for_download = "AT+MS=V92,1,300,24000,300,56000;+PIG=1\r"
modem_init_for_videocall = "AT+MS=V92,1,300,37333,300,37333;+PIG=0\r"
modem_init_for_videocall_p = "AT+MS=V34,1,300,31200,300,28800\r"
modem_init_for_v34       = "AT+MS=V34,1,300,31200,300,28800\r"
modem_init_for_v92       = "AT+MS=V92,1,300,37333,300,37333;+PIG=0\r"
modem_init_for_v34_sms   = "ATB3;+MS=V34,1,300,31200,300,28800\r"
modem_init_for_v92_sms   = "ATB3;+MS=V92,1,300,37333,300,37333;+PIG=0\r"
modem_init_for_sms_p = "ATB3;+MS=V34,1,300,31200,300,28800\r"

# modem initial command
modem_init1 = "AT+GCI=59;+VCID=1;+FCLASS=0;E0;&K3;+MS=V92,1,300,37333,300,37333\r"
modem_init2 = "ATX3;+PIG=0;!481D=40;!481E=0D;!481F=C0;!4820=11;+DS=0;+DS44=0\r"

modem_init1_v34 = "AT+GCI=59;+VCID=1;+FCLASS=0;E0;&K3;+MS=V34,1,300,31200,300,31200\r"
modem_init2_v34 = "ATX3;!481D=40;!481E=0D;!481F=C0;!4820=11;+DS=0;+DS44=0\r"

modem_init3 = "ATS6="+'%s'%(timerT4_2/1000)+";+IBC=0;+MR=1;!1297=40\r"

# parallel connection setting
modem_init1_p = "AT+GCI=59;+VCID=1;+FCLASS=0;E0;&K3;+MS=V34,1,300,31200,300,28800\r"
modem_init2_p = "ATX3;!481D=40;!481E=0D;!481F=C0;!4820=11;+DS=0;+DS44=0\r"
modem_init3_p = "ATS6="+'%s'%(timerT4_2/1000)+";+IBC=0;+MR=1;!482B=03\r"

#for DIAG
modem_init1_d = "AT+GCI=59;+VCID=1;&K3\r"
modem_init2_d = "ATX3;!481D=40;!481E=0D;!481F=C0;!4820=11\r"
modem_init3_d = "ATS6=3\r"


# for PCM UPSTREAM PATCH
#modem_init2 = "ATX3;+PIG=0;!481D=40;!481E=0D;!481F=C0;!4820=11;+DS=0;+DS44=0;!1297=70\r"
# for PCM UPSTREAM ON
#modem_init2 = "ATX3;+PIG=1;!481D=40;!481E=0D;!481F=C0;!4820=11;+DS=0;+DS44=0;!1297=70\r"

# LOCAL TEST �ÿ��� init1, init2�� �Ʒ��ɷ� ����ϼ���.######
#modem_init1 = "AT+VCID=1;+FCLASS=0;E0;&K3\r"
#modem_init2 = "ATX3\r"
#############################################################

#modem_init3 = "ATS6=2;+IBC=0;+MR=1\r"
#modem_init3 = "ATS6=4;+IBC=0;+MR=1\r"

# DTMF on/off time
dtmf_duration = 0.08
dtmf_pause = 0.06

# call type
NORMAL_CALL='0'		# or ' ' 
VIDEO_CALL='1'
NORMAL_INT_CALL='2'
VIDEO_INT_CALL='3'

#vocal cid
tts_test_mode = True # for pre-recoding test in TTS module.
# if False then bin/ttsplayer.org -> bin/ttsplayer

# profile
profile_dir = '/usr/etc/'
profile_file = profile_dir + 'profile'
lan_profile_file = profile_dir + 'ethernet.cfg'
wifi_profile_file = profile_dir + 'wireless.cfg'

# max internal number length
max_internal_number_len=4 # requested by fuscaldo 2005-09-07

dial_interdigit_timer = 4000 # interdigit timer for offhook dialing

#tiservice(aptcp) : cli selections
tisvc_timer_retry = (5 * 60 * 1000) # 5 min
tisvc_timer_retry_end = (24 * 60 * 60 * 1000) # 1 day

# firstsms
check_first_sms_enable='/usr/etc/first_sms.enabled'
dest_first_sms = '41183'
sc1_first_sms = '04211'
check_file_first_sms = '/usr/etc/sent_first_sms'
#check_first_sms_time = 60*60*1000
check_first_sms_time = 60*60*1000
max_first_sms_try = 5

# firstnotice
check_first_notice_disable='/usr/etc/first_notice.disabled'

stun_server = 'sun16217.cselt.it'

#LongTimeLanDown = 10*3	# sec
LongTimeLanDown = 0	# disable
