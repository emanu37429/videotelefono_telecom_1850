#!/usr/bin/python

import string
import sys
import templates

outf = open('gen.c', 'w')
#outf.write(templates.header)

db = []

for l in open('mibs.txt').readlines():
	l = l.strip()
	if l.find('#') >= 0:
		l = string.strip(l[:l.find('#')])
	
	if not l:
		continue

	tokens = [t.strip() for t in l.split(',')]
	if len(tokens) != 6:
		print 'Malformed line [%s]' % l
		sys.exit(0)
	
	oid,name,type,getfunc,setfunc,range = tokens
	if range.find('..') > 0:
		min,max = range.split('..')
		min_max_check = 1
	elif int(range) < 0:
		min,max = -1,-1
		min_max_check = 0
	else:
		min = max = int(range)
		min_max_check = 1

	val_dict = {
		'oid' : oid,
		'name' : name,
		'type' : type,
		'getfunc' : getfunc,
		'setfunc' : setfunc,
		'min_max_check' : min_max_check,
		'val_min' : min,
		'val_max' : max,

	}
	if setfunc:
		val_dict['rw_flag'] = 'HANDLER_CAN_RWRITE';
	else:
		val_dict['rw_flag'] = 'HANDLER_CAN_RONLY';

	db.append(val_dict)

	if type == 'string':
		if setfunc:
			template = templates.handler_string_rw
		else:
			template = templates.handler_string_ro
	elif type == 'int':
		if setfunc:
			template = templates.handler_int_rw
		else:
			template = templates.handler_int_ro
	elif type == 'ip':
		if setfunc:
			template = templates.handler_ip_rw
		else:
			template = templates.handler_ip_ro
	else:
		print 'Unknown type [%s]' % type
		sys.exit(0)
	
	outf.write(template % val_dict)

if 0:
	outf.write('void\n')
	outf.write('init_handlers(void)\n')
	outf.write('{\n')
	
	t = 'static oid %(name)s_oid[] = { 1, 3, 6, 1, 4, 1, 20070, 2, 1, %(oid)s };\n'
	for d in db:
		outf.write(t % d)
	
	t = """netsnmp_register_scalar(netsnmp_create_handler_registration
		("%(name)s", handle_%(name)s, %(name)s_oid,
		OID_LENGTH(%(name)s_oid),
		%(rw_flag)s));
	"""
	for d in db:
		outf.write(t % d)
	
		
	outf.write('}\n')
