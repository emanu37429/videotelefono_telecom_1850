header = \
"""
#include <assert.h>

#include <net-snmp/net-snmp-config.h>
#include <net-snmp/net-snmp-includes.h>
#include <net-snmp/agent/net-snmp-agent-includes.h>
#include "vdtProduct.h"

#include "vdtcore.h"
#include "commons.h"

oid  vdtProduct_variables_oid[] = { 1, 3, 6, 1, 4, 1, 20070, 2, 1 };

"""

handler_string_rw = \
"""
u_char *
var_%(name)s(struct variable *vp,
			oid *name,
			size_t *length,
			int exact,
			size_t *var_len,
			WriteMethod **write_method)
{
	char *val;
	int rc;

	if(header_generic(vp, name, length, exact, var_len, write_method) == MATCH_FAILED){
		return NULL;
	}

	*write_method = write_%(name)s;
	rc = %(getfunc)s(&val);
	if(rc) return NULL;
	*var_len = strlen(val);
	return val;
}

char *cache_%(name)s = NULL;
int
write_%(name)s(int action,
				u_char *var_val,
				u_char var_val_type,
				size_t var_val_len,
				u_char *statP, oid *name, size_t name_len)
{
	char *val;
	int rc;

	switch(action){
	case RESERVE1:
		if( var_val_type != ASN_OCTET_STR ){
			return SNMP_ERR_WRONGTYPE;
		}
		if(%(min_max_check)s){
			if( var_val_len < %(val_min)s || var_val_len > %(val_max)s ){
				return SNMP_ERR_WRONGLENGTH;
			}
		}
		break;
	case RESERVE2:
		rc = %(getfunc)s(&val);
		if(rc) return rc;

		assert(val);
		cache_%(name)s = str_dup(val, %(val_max)s);
		if(!cache_%(name)s) return SNMP_ERR_RESOURCEUNAVAILABLE;
		break;
	case FREE:
		if(cache_%(name)s){
			free(cache_%(name)s);
			cache_%(name)s = NULL;
		}
		break;
	case ACTION:
		var_val[var_val_len] = '\\0';
		rc = %(setfunc)s(var_val);
		if(rc) return rc;
		break;
	case UNDO:
		%(setfunc)s(cache_%(name)s);
		break;
	default:
		return SNMP_ERR_GENERR;
	}

	return SNMP_ERR_NOERROR;
}

"""

handler_string_ro = \
"""
u_char *
var_%(name)s(struct variable *vp,
			oid *name,
			size_t *length,
			int exact,
			size_t *var_len,
			WriteMethod **write_method)
{
	char *val;
	int rc;

	if(header_generic(vp, name, length, exact, var_len, write_method) == MATCH_FAILED){
		return NULL;
	}

	rc = %(getfunc)s(&val);
	if(rc) return NULL;
	*var_len = strlen(val);
	return val;
}
"""

handler_int_ro = \
"""
u_char *
var_%(name)s(struct variable *vp,
			oid *name,
			size_t *length,
			int exact,
			size_t *var_len,
			WriteMethod **write_method)
{
	int val;
	int rc;

	if(header_generic(vp, name, length, exact, var_len, write_method) == MATCH_FAILED){
		return NULL;
	}

	rc = %(getfunc)s(&val);
	if(rc) return NULL;
	*var_len = sizeof(val);
	long_return = val;
	return (u_char *)&long_return;
}
"""

handler_int_rw = \
"""
u_char *
var_%(name)s(struct variable *vp,
			oid *name,
			size_t *length,
			int exact,
			size_t *var_len,
			WriteMethod **write_method)
{
	int val;
	int rc;

	if(header_generic(vp, name, length, exact, var_len, write_method) == MATCH_FAILED){
		return NULL;
	}

	*write_method = write_%(name)s;
	rc = %(getfunc)s(&val);
	if(rc) return NULL;
	*var_len = sizeof(val);
	long_return = val;
	return (u_char *)&long_return;
}

int cache_%(name)s;
int
write_%(name)s(int action,
				u_char *var_val,
				u_char var_val_type,
				size_t var_val_len,
				u_char *statP, oid *name, size_t name_len)
{
	int val;
	int rc;

	switch(action){
	case RESERVE1:
		if( var_val_type != ASN_INTEGER){
			return SNMP_ERR_WRONGTYPE;
		}
		if(%(min_max_check)s){
			val = *((int *)var_val);
			if( val < %(val_min)s || val > %(val_max)s ){
				return SNMP_ERR_WRONGLENGTH;
			}
		}
		break;
	case RESERVE2:
		rc = %(getfunc)s(&val);
		if(rc) return rc;
		cache_%(name)s = val;
		break;
	case FREE:
		break;
	case ACTION:
		rc = %(setfunc)s(*((int *)var_val));
		if(rc) return rc;
		break;
	case UNDO:
		%(setfunc)s(cache_%(name)s);
		break;
	default:
		return SNMP_ERR_GENERR;
	}

	return SNMP_ERR_NOERROR;
}

"""

handler_ip_rw = \
"""
u_char *
var_%(name)s(struct variable *vp,
			oid *name,
			size_t *length,
			int exact,
			size_t *var_len,
			WriteMethod **write_method)
{
	unsigned int val;
	int rc;

	if(header_generic(vp, name, length, exact, var_len, write_method) == MATCH_FAILED){
		return NULL;
	}

	*write_method = write_%(name)s;
	rc = %(getfunc)s(&val);
	if(rc) return NULL;
	*var_len = sizeof(val);
	long_return = val;
	return (u_char *)&long_return;
}

int cache_%(name)s;
int
write_%(name)s(int action,
				u_char *var_val,
				u_char var_val_type,
				size_t var_val_len,
				u_char *statP, oid *name, size_t name_len)
{
	unsigned int val;
	int rc;

	switch(action){
	case RESERVE1:
		if( var_val_type != ASN_IPADDRESS){
			return SNMP_ERR_WRONGTYPE;
		}
		break;
	case RESERVE2:
		rc = %(getfunc)s(&val);
		if(rc) return rc;
		cache_%(name)s = val;
		break;
	case FREE:
		break;
	case ACTION:
		rc = %(setfunc)s(*((int *)var_val));
		if(rc) return rc;
		break;
	case UNDO:
		%(setfunc)s(cache_%(name)s);
		break;
	default:
		return SNMP_ERR_GENERR;
	}

	return SNMP_ERR_NOERROR;
}

"""
handler_ip_ro = \
"""
u_char *
var_%(name)s(struct variable *vp,
			oid *name,
			size_t *length,
			int exact,
			size_t *var_len,
			WriteMethod **write_method)
{
	unsigned int addr;
	int rc;

	rc = %(getfunc)s(&addr);
	if(rc) return NULL;
	*var_len = sizeof(addr);
	long_return = addr;
	return (u_char *)&long_return;
}
"""

