#!/bin/env python

import commands
import os
import time

host='192.168.1.2'
snmpget='snmpget -c public -v 2c %s TELECOMITALIA-VDT-MIB::' % host
snmpset='snmpset -c public -v 2c %s TELECOMITALIA-VDT-MIB::' % host

os.system(snmpget+'productModel.0')
os.system(snmpset+'ftpHostIP.0 s 61.107.31.77')

files = [
	(839680, 'AppImage-1.0.1.tar'),
	(839680, 'AppImage-1.0.1.ta2'),
	(716800, 'Background-1.0.1.tar'),
	(942080, 'Melody-1.0.1.tar'),
	(942080, 'Melody-1.0.1.ta2'),
	(911360, 'SoundFont-1.0.1.tar'),
	(911360, 'SoundFont-1.0.1.ta2'),
]

"""
	(174080, 'MiscBins-1.0.1.tar'),
	( 20480, 'Configuration-1.0.1.tar'),
	(645120, 'T9-1.0.1.tar'),
	(389120, 'Timidity-1.0.1.tar'),
	(184320, 'App-1.0.1.tar'),
	( 40960, 'IPTables-1.0.1.tar'),
	( 71680, 'Font-1.0.1.tar'),
	(204800, 'Freetype-1.0.1.tar'),
	(512000, 'GConv-1.0.1.tar'),
	(327680, 'GLib-1.0.1.tar'),
	(133120, 'Evas-1.0.1.tar'),
	(358400, 'Python-2.4.0.ta2'),
	(358400, 'Python-2.4.0.tar'),
	(245760, 'PPP-1.0.1.tar'),
	( 51200, 'ZLib-1.0.1.tar'),
	(460800, 'Snmpd-1.0.1.tar'),
	( 30720, 'SnmpModule-1.0.1.tar'),
	(112640, 'Png-1.0.1.tar'),
	( 51200, 'Locale-1.0.1.tar'),
	( 71680, 'KernelDrivers-1.0.1.tar'),
"""

total_size = 0
for s,f in files:
	total_size += s
	
os.system(snmpset+'ftpDataToBeDownloaded.0 i %d' % total_size)

for s,f in files:
	os.system(snmpset+'ftpPath.0 s "/pkg-all/%s"' % f)
	os.system(snmpset+'ftpDownloadTrigger.0 i 1')

	while True:
		time.sleep(1)
		os.system(snmpget+'ftpStatus.0')
		result = commands.getoutput(snmpget+'ftpDownloadTrigger.0')
		print 'XXXX result = [%s]' % result
		v = result.split('\n')[0].split()[-1] 
		print 'XXXX v = [%s]' % v
		if v == '0' or v == '3':
			break
		continue

	time.sleep(10)


os.system(snmpset+'reboot.0 i 1')
