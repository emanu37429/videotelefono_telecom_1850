arg=''

#while [ 1 ]; do
for ii in 0 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19; do
	# delete tmp video record.
	rm -r /usr/local/lgvp/_tmp_-*.mdat

	python vphone.pyc $arg $ii
	if [ $? -eq 0 ]; then
		break
	else
		killall -9 ppp-call
		killall -9 pppd
		killall -9 playulaw
		killall -9 VDCIApp
		killall -9 dimclient

		# by shchun: when kill python, lcd on as default	
		lcdoff 0
	
		#rmmod dspg
		#rmmod lgvp-ssp-audio

		cd /usr/local/drivers
		#insmod dspg.o
		sleep 2
		modem_hw_reset

		cd /lib/modules/2.4.25-vrs2-pxa1/kernel/drivers/sound
		#insmod lgvp-ssp-audio.o

		cd /usr/local/lgvp
		arg=restart
	fi
done
echo I am die. ^^
reboot
