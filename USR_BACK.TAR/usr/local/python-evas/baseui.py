import config, widget, runtime
import gobject
import time

class BaseUI:
	def __init__(self, left, right, title):
		self.timer_tag = 0
		self.left = left
		self.right = right
		self.title = title
		self.widgets = []

	def show(self):
		print 'show', self.widgets
		self.update_background_widgets()
		for w in self.widgets:
			w.show()
		runtime.canvas.render()

	def add(self, widget):
		self.widgets.append(widget)

	def hide(self):
		for w in self.widgets:
			w.hide()
		runtime.canvas.render()

	def destroy(self):
		for w in self.widgets:
			w.free()
		self.widgets = []
		runtime.canvas.render()

	def center_align(self, label, pos):
		x, y = pos
		w, h = label.geometry[2:]
		label.move(x - w / 2, y)

	def set_left(self, left):
		self.left = left
		runtime.lb.set_text(left)

	def set_right(self, right):
		self.right = right
		runtime.rb.set_text(right)

	def set_title(self, title):
		self.title = title
		runtime.title.set_text(title)

	def handle_key(self, down, keyname):
		return False

	def update_background_widgets(self):
		runtime.lb.set_text(self.left)
		runtime.rb.set_text(self.right)
		runtime.title.set_text(self.title)

	def change_language(self):
		pass

class ListUI(BaseUI):

	def set_list(self, labels):
		self.list = widget.List(labels)
		self.add(self.list)

	def handle_key(self, down, keyname):
		if keyname == 'Up':
			self.list.focus_up()
			return True
		elif keyname == 'Down':
			self.list.focus_down()
			return True
		return False

	def get_focus(self):
		return self.list.focus

	def set_focus(self, focus):
		self.list.set_focus(focus)

	def set_text(self, n, text):
		self.list.set_text(n, text)

	def change_language(self):
		self.list.change_language()
		
		

class GaugeUI(BaseUI):
	def __init__(self, left, right, title):
		BaseUI.__init__(self, left, right, title)
		self.gauge = widget.Gauge()
		self.add(self.gauge)

	def set_value(self, value):
		self.gauge.set_value(value)

	def get_value(self):
		return self.gauge.get_value()

	def handle_key(self, down, keyname):
		if keyname == 'Up':
			self.gauge.value_up()
			return True
		elif keyname == 'Down':
			self.gauge.value_down()
			return True
		return False

class EntryUI(BaseUI):
	def __init__(self, left, right, title, subtitle):
		BaseUI.__init__(self, left, right, title)
		self.subtitle = runtime.canvas.text(text=subtitle,font=config.entry_sublabel_font,
			pos=config.entry_sublabel_pos)
		self.add(self.subtitle)
		self.subtitle_text = subtitle
		self.entry = widget.Entry()
		self.add(self.entry)

	def set_subtitle(self, text):
		self.subtitle_text = text
		self.subtitle.text = text

	def insert(self, text):
		self.entry.insert(text)

	def get_text(self):
		return self.entry.text

	def set_text(self, text):
		return self.entry.set_text(text)

	def delete_char(self):
		self.set_text(self.get_text()[:-1])

	def handle_key(self, down, keyname):
		if keyname == 'BackSpace':
			if len(self.get_text()) > 0:
				self.set_text(self.get_text()[:-1])
			return True
		elif len(keyname) == 1:
			self.set_text(self.get_text() + keyname)
			return True
		return False

	def change_language(self):
		self.subtitle.text = self.subtitle_text

class YesNoUI(BaseUI):
	def __init__(self, title, message):
		BaseUI.__init__(self, 'OK','No',title)
		self.message = widget.Label(text=message,font=config.yesno_font,pos=config.yesno_pos,color=config.yesno_color)
		self.add(self.message)

	def change_language(self):
		self.message.change_language()

class GalleryUI(BaseUI):
	def __init__(self, title):
		BaseUI.__init__(self, 'Options','No', title)
		self.image = runtime.canvas.image()
		self.image.geometry = config.gallery_geometry
		self.add(self.image)

	def set_pic(self, image_file):
		self.image.image_file = image_file

class MessageUI(BaseUI):
	def __init__(self, left, right, title, message):
		BaseUI.__init__(self, left, right, title)
		self.label = widget.Label(text=message,font=config.notify_font,pos=config.notify_pos,color=config.notify_color)
		self.add(self.label)

	def change_language(self):
		self.label.change_language()

class NotifyUI(BaseUI):
	def __init__(self, message):
		BaseUI.__init__(self, '', '', '')
		self.label = widget.Label(text=message,font=config.notify_font,pos=config.notify_pos,color=config.notify_color)
		self.add(self.label)
	def change_language(self):
		self.label.change_language()

def _make_fixed_widget():
	runtime.lb = widget.Label('',font=config.button_font,pos=config.left_button_pos,color=config.button_color)
	runtime.rb = widget.Label('',font=config.button_font,pos=config.right_button_pos,color=config.button_color)
	runtime.title = widget.Label('', font=config.title_font, pos=config.title_pos, color=config.title_color)
	runtime.timer = runtime.canvas.text(text='', font=config.timer_font, pos=config.timer_pos,color=config.timer_color)
	def update_timer():
		lt = time.localtime()
		runtime.timer.text_set("%02d:%02d" % (lt[4], lt[5]))
		runtime.canvas.render()
		return True

	runtime.timer_tag = gobject.timeout_add(500, update_timer)
	update_timer()
	for w in runtime.lb, runtime.rb, runtime.title, runtime.timer:
		w.show()

def ui_init(exit_cb):
	import evas
	runtime.canvas = canvas = evas.Evas(config.width, config.height, config.rotation)
	canvas.image_cache_set(4*1024*1024)
	canvas.font_cache_set(1024*1024)
	dir_lists = ('/home/hwang/opt/share/evas/data', '/usr/local/share/evas/data')
	import os
	for d in dir_lists:
		if os.access(d, os.R_OK):
			canvas.font_path_prepend(d)
			break

	canvas.bg = bg = canvas.rectangle(pos=(0,0),size=(config.width,config.height))
	bg.layer = -99
	bg.color = 0, 0, 80, 255

	w = 189
	h = 88
	x = 320 - w
	x = x / 2
	y = 240 - h
	y = y / 2
	lglogo = canvas.image(pos=(x,y), size=(w,h), file='lglogo.png')
	lglogo.smooth_scale_set(0)
	lglogo.fill_set(0, 0, w, h)
	lglogo.show()

	def key_down_cb(ev):
		print 'key press', ev.keyname
		if ev.keyname == 'q':
			exit_cb()
		canvas.handle_key(True, ev.keyname)

	def key_up_cb(ev):
		print 'key release', ev.keyname
		canvas.handle_key(False, ev.keyname)

	bg.event_callback_add(evas.CALLBACK_KEY_DOWN, key_down_cb)
	bg.event_callback_add(evas.CALLBACK_KEY_UP, key_up_cb)
	bg.focus_set(True)
	bg.show()
	lglogo.show()
	_make_fixed_widget()

