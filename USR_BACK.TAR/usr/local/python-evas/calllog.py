# -*- encoding: euc-kr -*-

from basemodel import ListStage,NotifyStage,YesNoStage
import runtime

class DetailStage:
	pass

class DetailStage1(DetailStage):
	# options���κ��� ����� detail stage
	pass

class DetailStage2(DetailStage):
	# call listup���� right key�� ���� ����� detail stage
	pass

def SaveStage():
	pass

def CallStage():
	pass

def SendSMSStage():
	pass

def HiddenCallStage():
	pass

class DeleteStage(YesNoStage):
	def __init__(self):
		def yes():
			# delete this entry: FIXME
			def destroy():
				runtime.manager.queue_backward(2)
				return False
			stage = NotifyStage('Entry Deleted!')
			runtime.manager.stack_stage(stage)
		def no():
			runtime.manager.back_stage()
		YesNoStage.__init__(self, 'Delete this entry?', yes, no, 'Delete')
	

class OptionsStage(ListStage):
	title = 'Options'
	choice = 'Details', 'Save', 'Delete', 'Send SMS', 'Call', 'Hidden Call'
	def activate(self, index):
		stage = (DetailStage1, SaveStage, DeleteStage, SendSMSStage, CallStage, HiddenCallStage)[index]
		runtime.manager.stack_stage(stage)
			

class CallLogStage(ListStage):
	def __init__(self, lst):
		ListStage.__init__(self, choice=lst)
		self.ui.set_left('Options')

	def activate(self, index):
		runtime.manager.stack_stage(OptionsStage)

	def handle_key(self, down, keyname):
		if keyname == 'right':
			print 'goto detail'

			return True

	
class MissedStage(ListStage):
	title = 'Missed Calls'
	def __init__(self):
		import calldb
		choice = calldb.get_missed_list()
		CallLogStage.__init__(self, choice)

	def handle_key(self, down, keyname):
		if not down:
			return False

	def activate(self, index):
		pass

class ReceivedStage(ListStage):
	title = 'Missed Calls'
	def __init__(self):
		import calldb
		choice = calldb.get_received_list()
		ListStage.__init__(self, choice=choice)

	def activate(self, index):
		pass
		
class DialledStage(ListStage):
	title = 'Missed Calls'
	def __init__(self):
		import calldb
		choice = calldb.get_dialled_list()
		ListStage.__init__(self, choice=choice)

	def activate(self, index):
		pass

class DeleteStage(ListStage):
	title = 'Delete'
	choice = 'Missed Calls','Received Calls','Dialled Calls','All Calls'

	def activate(self, index):
		def yes_cb():
			print 'really delete', index
			stage = NotifyStage('List Deleted')
			runtime.manager.change_stage(stage, clear_history=True)
		def no_cb():
			runtime.manager.back_stage()
		stage = YesNoStage('Delete List?', yes_cb, no_cb, 'Delete')
		runtime.manager.stack_stage(stage)


_stages = MissedStage, ReceivedStage, DialledStage, DeleteStage
def get_stage(index):
	return _stages[index]
