# missed calls
# received calls
# dialled calls
import phonedb

#calls = (number, date, call_time, video_call_time)
missed_calls = []
received_calls = []
dialled_calls = []

def get_list(db):
	calls = []
	find = phonedb.phonedb.find
	get_item = phonedb.phonedb.get_item
	for number in db:
		index = find(number)
		if index > 0:
			number = get_item(index)[0]
		calls.append(number)
	return calls

def get_missed_calls():
	return get_list(missed_calls)

def get_received_calls():
	return get_list(received_calls)

def get_dialled_calls():
	return get_list(dialled_calls)

def load_db():
	global missed_calls, received_calls, dialled_calls
	def load_file(file):
		try:
			db = []
			for line in open(file).readlines():
				item = line.split()
				assert len(item) == 4
				db.append(item)
			return db
		except:
			return []

	missed_calls = load_file('missed.txt')
	received_calls = load_file('received.txt')
	dialled_calls = load_file('dialled.txt')

def save_db():
	def save_file(db, file):
		fp = open(file, 'w')
		for item in db:
			fp.write(' '.join(item) + '\n')

	save_file(missed_calls, 'missed.txt')
	save_file(received_calls, 'received.txt')
	save_file(dialled_calls, 'dialled.txt')

