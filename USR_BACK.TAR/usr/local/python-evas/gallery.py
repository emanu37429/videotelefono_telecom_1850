from basemodel import Stage, ListStage
import runtime
import baseui

class OptionStage(ListStage):
	title = 'Options'
	choice = 'Add','Delete'
	def activate(self, index):
		print 'xx'

class GalleryStage(Stage):
	def __init__(self):
		self.ui = baseui.GalleryUI('Gallery - View')
		self.ui.show()

	def handle_key(self, down, keyname):
		if not down:
			return False
		if keyname == config.Menu1:
			# option
			runtime.manager.stack_stage(OptionStage)
		elif keyname == config.Menu2:
			# Back
			runtime.manager.back_stage()
		elif keyname in ('Up', 'Down'):
			self.ui.handle_key(down, keyname)
		else:
			return False
		return True

def AssignSnapshotStage():
	if picture.is_empty:
		stage = basemodel.NotifyStage('Gallery is Empty!')
		stage.ui.set_title('Gallery View')
		runtime.manager.stack_stage(stage)
	else:
		return GalleryStage()
