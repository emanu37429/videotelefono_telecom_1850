import ui, config
from basemodel import Stage, EntryStage
import runtime
import status
import gobject


class MenuStage(Stage):
	def __init__(self):
		self.ui = ui.MenuUI()
		self.ui.show()

	def handle_key(self, down, keyname):
		if not down:
			return False
		if keyname == config.Menu1:
			print self.ui.focus, 'OK'
			import menu
			stage = menu.get_stage(self.ui.focus)
			runtime.manager.stack_stage(stage)
		elif keyname == config.Menu2:
			print 'Back'
			runtime.manager.back_stage()
		else:
			return self.ui.handle_key(down, keyname)
		return True

class ConnectedStage(Stage):
	def __init__(self):
		self.ui = ui.ConnectedUI()
		self.ui.show()
		self.update_time_tag = 0

	def handle_key(self, down, keyname):
		if not down:
			return False
		if keyname == 'Up':
			# volume up
			pass
		elif keyname == 'Down':
			# volume down
			pass
		return False

	def handle_command(self, command):
		pass

	def update_time(self):
		return True

	def show(self):
		if self.update_time_tag == 0:
			self.update_time_tag = gobject.timeout_add(200, self.update_time)
		State.show(self)

	def hide(self):
		if self.update_time_tag > 0:
			gobject.source_remove(self.update_time_tag)
			self.update_time_tag = 0
		State.hide(self)

	def destroy(self):
		if self.update_time_tag > 0:
			gobject.source_remove(self.update_time_tag)
			self.update_time_tag = 0
		State.destroy(self)

class VideoCallStage(Stage):
	def __init__(self):
		self.ui = ui.VideoCallUI()
		self.ui.show()
		runtime.manager.modem.monitor(False)

	def handle_key(self, down, keyname):
		if not down:
			return False
		if keyname == config.Red:
			import os
			os.system('ppp-stop')
			os.system('modem_hw_reset')
			os.system('killall python')
			runtime.manager.change_stage(IdleStage)
			runtime.manager.modem.monitor(True)
			return True
		return False

class DialStage(EntryStage):
	def __init__(self):
		EntryStage.__init__(self, 'Number:', '', left='Options', right='Back')

	def activate_menu1(self):
		status.set_dial_number(self.ui.get_text())
		import options
		stage = options.PreDialOptionsStage
		runtime.manager.stack_stage(stage)

	def handle_key(self, down, keyname):
		if not down:
			return False
		if keyname == config.Video:
			status.set_dial_number(self.ui.get_text())
			print 'video key', 'current dial', status.dial_number
			import os
			os.system('ppp-call ' + status.dial_number)
			stage = VideoCallStage
			runtime.manager.change_stage(stage, True)
			return True
		elif keyname == config.Green:
			status.set_dial_number(self.ui.get_text())
			status.phone_status = status.Dialing
			import modem
			modem.voice_call(status.dial_number)
			return True
		else:
			return EntryStage.handle_key(self, down, keyname)

	def handle_event(self, command):
		pass

	def show(self):
		self.ui.set_text(status.dial_number)
		EntryStage.show(self)

class IdleStage(Stage):
	def __init__(self):
		self.ui = ui.IdleUI()
		self.ui.show()

	def handle_key(self, down, keyname):
		if not down:
			return
		if keyname == config.Menu1:
			print 'Run Main Menu'
			runtime.manager.stack_stage(MenuStage)
		elif keyname == config.Menu2:
			print 'Run phone book'
			import phonebook
			stage = phonebook.get_phonebook_stage()
			runtime.manager.stack_stage(stage)
		elif keyname == config.Red:
			import os
			os.system('ppp-stop')
			os.system('modem_hw_reset')
			os.system('killall python')
		elif keyname in '0123456789*#':
			stage = DialStage
			runtime.manager.stack_stage(stage)
			runtime.manager.handle_key(down, keyname)
		elif keyname == 'Left':
			# Telecom Italia TAM service
			pass
		elif keyname == 'Right':
			# Telecom Italia Ultime Chiamate service
			pass
		elif keyname == 'Up':
			# Dialled Number
			pass
		elif keyname == 'Down':
			# Phonebook
			pass
		else:
			print 'idle stage key:', keyname

	def handle_event(self, command):
		if command == 'off-hook':
			runtime.manager.change_stage(DialStage)

	def show(self):
		assert not runtime.manager.back 
		Stage.show(self)

			

class Manager:
	def __init__(self):
		runtime.canvas.handle_key = self.handle_key
		self.back = []
		self.stage = IdleStage()
		import modem
		self.modem = modem.Modem(self.handle_modem)
		return

	def handle_key(self, down, keyname):
		# long/short key
		if keyname == config.OnHook:
			if down:
				status.set_hook(True)
		elif keyname == config.OffHook:
			if down:
				status.set_hook(False)
		self.stage.handle_key(down, keyname)

	def handle_modem(self, *ev):
		evtype = ev[0]
		if evtype == 'connect':
			status.phone_status = status.VoiceConnected
		elif evtype == 'disconnect':
			status.phone_status = status.Disconnected
		elif evtype == 'ring':
			print 'ring'

			stage = VideoCallStage
			runtime.manager.change_stage(stage, True)

	#		import os
	#		os.system('ini;ppp-answer')
			try:
				runtime.manager.modem.write('ATA\r')
			except:
				pass
			import os
			os.system('ppp-answer')
		elif evtype == 'dtmf':
			print 'dtmf', ev[1]
		elif evtype == 'cid':
			number = ev[1]
			status.caller_number = number
			print 'cid', number
		else:
			self.stage.handle_modem(*ev)

	def change_stage(self, stage, clear_history=False):
		if clear_history:
			for s in self.back:
				s.destroy()
			self.back = []
		self.stage.destroy()
		if callable(stage):
			stage = stage()
		self.stage = stage

	def stack_stage(self, stage):
		self.stage.hide()
		self.back.append(self.stage)
		if callable(stage):
			stage = stage()
		self.stage = stage

	def queue_backward(self, count):
		def back():
			print 'back callback', count
			for i in range(count):
				self.back_stage()
			return False
		gobject.idle_add(back)

	def change_langauge(self):
		self.stage.ui.change_language()
		for stage in self.back:
			stage.ui.change_language()
		#### update back widgets

	def back_stage(self):
		print self, self.stage
		self.stage.destroy()
		if self.back:
			stage = self.back.pop()
		else:
			stage = IdleStage()
		self.stage = stage
		print 'back stage', stage
		stage.show()

