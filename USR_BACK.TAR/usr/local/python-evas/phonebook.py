from basemodel import ListStage, EntryStage, Stage
import baseui, runtime
import config, status
from phonedb import phonedb

class FindStage(EntryStage):
	def __init__(self):
		#sub_label, title, left='Ok', right='Back'):
		EntryStage.__init__(self, 'Name:', 'Find:', 'Find')

	def activate_menu1(self):
		# 'Find'
		text = self.ui.get_text()
		focus = phonedb.find_near(text)
		stage = PhoneListStage(focus)
		runtime.manager.change_stage(stage)

	def activate_menu2(self):
		runtime.manager.back_stage()

class ToneStage(ListStage):
	title = 'Add Entry - Tone'
	choice = 'Badinerie', 'Jingle Bells', 'Guglielmo Tell', 'Polonaise'
	def activate(self, index):
		status.phone_item.tone = str(index)
		stage = basemodel.NotifyStage('Tone Selected!')
		stage.ui.set_title('Add Entry - Tone')
		runtime.manager.change_stage(stage)

def VIPStage():
	status.phone_item.vip = 'true'
	stage = basemodel.NotifyStage('Set as VIP!')
	stage.ui.set_title('Add Entry - VIP')
	return stage

		
class CallTypeStage(ListStage):
	title = 'Add Entry - Call Type'
	choice = 'Normal Call', 'Video Call', 'Normal Call INT', 'Video Call INT'
	def activate(self, index):
		status.phone_item.call_type = str(index)
		stage = basemodel.NotifyStage(self.choice[index] + ' Selected!')
		stage.ui.set_title('Add Entry - Call Type')
		runtime.manager.change_stage(stage)
		
def AssignSnapshotStage():
	import gallery
	return gallery.AssignSnapshotStage()
		
class AddLastStage(ListStage):
	title = 'Add Entry'
	choice = 'Save', 'Assign Tone', 'Set as VIP', 'Set Call Type', 'Assign Snapshot'
	def activate(self, index):
		if index == 0:
			phonedb.insert_item(status.phone_item)
			stage = basemodel.NotifyStage('Entry Saved!')
			stage.ui.set_title('Add Entry - Save')
			runtime.manager.change_stage(stage)
			return
		stage = (None, ToneStage, VIPStage, CallTypeStage, AssignSnapshotStage)[index]
		runtime.manager.stack_stage(stage)



class AddStage(EntryStage):
	# name, number, mobile, email, fax
	names = 'Name:', 'Number:', 'Mobile:', 'E-Mail Address:', 'Fax Number:'
	def __init__(self):
		#sub_label, title, left='Ok', right='Back'):
		EntryStage.__init__(self, 'Name:', 'Add Entry', left='Next')
		self.level = 0
		status.reset_phone_item()

	def activate_menu1(self):
		text = self.ui.get_text()
		status.set_phone_item(self.level, text)

		self.level += 1
		if self.level > 4:
			stage = AddLastStage
			runtime.manager.change_stage(stage)
		else:
			self.ui.set_subtitle(self.names[self.level])
			self.ui.set_text('')

	def activate_menu2(self):
		self.level -= 1
		if self.level > 0:
			self.ui.set_subtitle(self.names[self.level])
			text = status.editing_phone_item[self.level]
			self.ui.set_text(text)
			if text:
				self.ui.set_right('Delete')
		else:
			runtime.manager.back_stage()

class ModifyOptionStage(ListStage):
	title = 'Modify'
	choice = 'Modify Number','Modify Name','Modify E-Mail','Modify Fax','Modify Snapshot', \
		'Modify Tone', 'Modify VIP', 'Modify Call Type'
	def activate(self, index):
		pass
		
	
class ModifyListStage(ListStage):
	def __init__(self, focus):
		self.ui = baseui.ListUI('Options', 'Back', 'Modify')
		choice = phonedb.get_names()
		self.ui.set_list(choice)
		self.ui.show()
		self.ui.set_focus(focus)

	def activate(self, index):
		status.editing_phone_number_index = index	
		stage = ItemOptionStage
		runtime.manager.stack_stage(stage)

class ModifyStage(EntryStage):
	def __init__(self):
		EntryStage.__init__(self, 'Name:', 'Modify', left='Find')

	def activate_menu1(self):
		# 'Find'
		text = self.ui.get_text()
		focus = phonedb.find_near(text)
		stage = ModifyListStage(focus)
		runtime.manager.change_stage(stage)
	def activate_menu2(self):
		runtime.manager.back_stage()

class DeleteStage:
	pass

class VIPStage:
	pass

class DetailStage(ListStage):
	def __init__(self):
		title = ''
		ListStage.__init__(self, title=title)
		self.ui.set_left('Call')

	def activate(self, index):
		pass

class ItemOptionStage(ListStage):
	title = 'Options'
	choice = 'Details', 'Modify', 'Delete'

	def activate(self, index):
		if index == 0:
			runtime.manager.stack_stage(DetailStage)
		elif index == 1:
			# Modify Stage
			pass
		else:
			# Delete This Item
			# FIXME propagate this change to UI
			phonedb.remove(status.editing_phone_number_index)

class PhoneListStage(ListStage):
	def __init__(self, focus):
		self.ui = baseui.ListUI('Options', 'Back', 'Phonebook')
		choice = phonedb.get_names()
		self.ui.set_list(choice)
		self.ui.show()
		self.ui.set_focus(focus)

	def activate(self, index):
		status.editing_phone_number_index = index	
		stage = ItemOptionStage
		runtime.manager.stack_stage(stage)

class PhoneBookStage(ListStage):
	title = 'Phonebook'
	choice = 'Find', 'Add Entry', 'Modify', 'Delete', 'VIP List'
	def activate(self, index):
		stage = (FindStage, AddStage, ModifyStage, DeleteStage, VIPStage)[index]
		runtime.manager.stack_stage(stage)

class PhoneBookEmptyStage(Stage):
	def __init__(self):
		self.ui = baseui.MessageUI('Add','Back','Phonebook','Phonebook is Empty')
		self.ui.show()
		#self.destroy_tag = gobject.timeout_add(

	def handle_key(self, down, keyname):
		if not down:
			return False
		if keyname == config.Menu1:
			print 'phonebook add'
			runtime.manager.change_stage(AddStage)
		elif keyname == config.Menu2:
			print 'Back'
			runtime.manager.back_stage()
		else:
			return False
		return True


def get_phonebook_stage():
	if phonedb.count() == 0:
		return PhoneBookEmptyStage
	return PhoneBookStage


