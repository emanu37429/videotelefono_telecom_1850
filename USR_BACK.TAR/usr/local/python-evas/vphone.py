#! /usr/bin/env python
# -*- encoding: euc-kr -*-

import gobject
import baseui
import model
import runtime

loop = gobject.MainLoop()

baseui.ui_init(loop.quit)
runtime.manager = model.Manager()

def check_intr_cb():
	return True
gobject.timeout_add(200, check_intr_cb)

loop.run()
