# -*- encoding: euc-kr -*-

import evas, config
import gobject
import time
import widget
import runtime

from baseui import BaseUI

class VideoCallUI(BaseUI):
	def __init__(self):
		BaseUI.__init__(self, '', '', '')
		rect = runtime.canvas.rectangle(pos=(0,0),size=(config.width,config.height))
		self.add(rect)


class IdleUI(BaseUI):
	def __init__(self):
		BaseUI.__init__(self, 'Menu', 'PhoneBook', 'Main')
		return

		day = runtime.canvas.text(text='Telecom Italia', font=config.idle_font)
		self.center_align(day, config.idle_pos)
		day.color = config.idle_color
		self.add(day)

		lt = time.localtime()
		day = runtime.canvas.text(text='%02d/%02d/%02d' % (lt[0], lt[1], lt[2]),
			font=('Vera', 24))
		self.center_align(day, (160, 65+30))
		self.add(day)

class DialUI(BaseUI):
	def __init__(self):
		BaseUI.__init__(self, 'Redial', 'PhoneBook', '')

class ConnectedUI(BaseUI):
	def __init__(self):
		BaseUI.__init__(self, 'Options', 'End', '')
		label = runtime.canvas.text(text='Call',font=config.connected_font) 

class MenuUI(BaseUI):
	def __init__(self):
		BaseUI.__init__(self, 'OK', 'Back', '')

		labels = ('Message\nCheck', 'Call\nLog', 'Phone\nSetting', 
			'TI\nService','Alarm\n','Video\nSetting')
		self.buttons = []
		xs = config.menu_button_pos_x
		ys = config.menu_button_pos_y
		for i in range(6):
			y, x = divmod(i, 3)
			ws = widget.MenuButton(labels[i], xs[x], ys[y])
			self.add(ws)
			self.buttons.append(ws)

		self.focus = -1
		self.set_focus(0)

	def set_focus(self, i):
		if self.focus == i:
			return
		if self.focus >= 0:
			r, t = self.buttons[self.focus].children
			r.color = config.menu_button_color_bg_normal
			t.set_color(config.menu_button_color_text_normal)
		r, t = self.buttons[i].children
		r.color = config.menu_button_color_bg_focus
		t.set_color(config.menu_button_color_text_focus)
		self.focus = i
		runtime.canvas.render()

	def handle_key(self, down, keyname):
		y, x = divmod(self.focus, 3)
		if keyname == 'Left':
			if x > 0: x -= 1
		elif keyname == 'Right':
			if x < 2: x += 1
		elif keyname == 'Up':
			if y > 0: y -= 1
		elif keyname == 'Down':
			if y < 1: y += 1
		else:
			return False
		self.set_focus(x + y * 3)
		return True

	def change_language(self):
		for w in self.buttons:
			w.change_language()

