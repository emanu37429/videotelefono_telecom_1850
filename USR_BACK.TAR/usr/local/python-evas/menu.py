import runtime
from basemodel import ListStage

class MessageStage(ListStage):
	title = 'Messages'
	choice = ('SMS','E-Mail','Fax','Delete',
			'Servizio 404', 'Settings')
	def activate(self, index):
		import message
		stage = message.get_stage(index)
		runtime.manager.stack_stage(stage)

class CallLogStage(ListStage):
	title = 'Call Log'
	choice = ('Missed Calls', 'Received Calls', 'Dialled Calls', 'Delete')
	def activate(self, index):
		import calllog
		stage = calllog.get_stage(index)
		runtime.manager.stack_stage(stage)

class PhoneSettingStage(ListStage):
	title = 'Phone Setting'
	choice = ('Ringer','Audio Volume','Date/Time','PABX Access Code',
			'Interdigit Pause','Call Barring',
			'Language', 'PIN',
			'Restore Default', 'Settings')
	def activate(self, index):
		import phonesetting
		stage = phonesetting.get_stage(index)
		runtime.manager.stack_stage(stage)

class TIServiceStage(ListStage):
	title = 'T.I. Service' 
	choice = ('Last Call', 'Last Calls', 'TAM', 'Info 412', 
			'Logos & Sounds', 'Call Transfer',
			'Call Waiting', 'Correct Time',
			'Wake Up Calls', 'Chiarotel',
			'Urgent Call', 'Service 5',
			'Auto-Disabilitazione',
			'Multi-Number', 'CID',
			'Hide Number')
	def activate(self, index):
		import tiservice
		stage = tiservice.get_stage(index)
		runtime.manager.stack_stage(stage)

class AlarmStage(ListStage):
	title = 'Agenda'
	choice = ('Set', 'Delete')
	def activate(self, index):
		import alarm
		stage = alarm.get_stage(index)
		runtime.manager.stack_stage(stage)

class VideoSettingStage(ListStage):
	title = 'Video Settings'
	choice = ('Video Quality','Video Dimension',
			'Video Mode','Menu color',
			'Background', 'Screen Saver')
	def activate(self, index):
		import videosetting
		stage = videosetting.get_stage(index)
		runtime.manager.stack_stage(stage)

_stages = MessageStage, CallLogStage, PhoneSettingStage, TIServiceStage, AlarmStage, VideoSettingStage

def get_stage(index):
	return _stages[index]
