from basemodel import ListStage

class LastCallStage:
	pass

class LastCallsStage:
	pass

class TAMStage(ListStage):
	title = 'TAM'
	choice = ('Enable not engaged','Enable busy/not', 'Disable','Check Status')
	def activate(self, index):
		pass

class Info412Stage:
	pass

class LogosStage:
	pass

class CallTransferStage:
	pass

class CallWaitingStage:
	pass

class CorrectTimeStage:
	pass

class WakeUpCallsStage:
	pass

class ChiarotelStage:
	pass

class UrgentCallStage:
	pass

class Service5Stage:
	pass

class AutoDisabilitazioneStage:
	pass

class MultiNumberStage:
	pass

class CIDStage:
	pass

class HideNumberStage:
	pass


_stages = LastCallStage, LastCallsStage, TAMStage, Info412Stage, LogosStage, CallTransferStage, \
	CallWaitingStage, CorrectTimeStage, WakeUpCallsStage, ChiarotelStage, UrgentCallStage, \
	Service5Stage, AutoDisabilitazioneStage, MultiNumberStage, CIDStage, HideNumberStage

def get_stage(index):
	return _stages[index]
