
record = 'name', 'number', 'mobile', 'email', 'fax', 'tone', 'vip', 'call_type', 'snapshot'


class PhoneDB:
	def __init__(self):
		self.db = []
		try:
			for line in open('phonenumber.txt').readlines():
				item = line[:-1].split(',')
				self.db.append(tuple(item))
				assert len(item) == len(record)
		except:
			pass

	def find(self, number):
		for i, item in enumerate(self.db):
			if number <= item[0]:
				if number == item[0]:
					return i
				return -1

	def get_item(self, i):
		assert 0 <= i < len(self.db)
		return self.db[i]


	def find_near(self, name):
		for i, item in enumerate(self.db):
			if name <= item[0]:
				return i

	def count(self):
		return len(self.db)

	def insert(self, name, number, mobile='', email='', fax='', tone='', vip='',call_type='',snapshot=''):
		self.insert_item((name, number, mobile, email, fax, tone, vip, call_type, snapshot))

	def insert_item(self, item):
		try:
			m = item
			item = m.name, m.number, m.mobile, m.email, \
				m.fax, m.tone, m.vip, m.call_type, m.snapshot
		except:
			pass
		self.db.append(tuple(item))
		def item_sort(x,y):
			print 'sort', x, y
			if x[0] > y[0]:
				return 1
			elif x[0] < y[0]:
				return -1
			if len(x) > 1:
				return item_sort(x[1:], y[1:])
			return 0
		self.db.sort(item_sort)
	def remove(self, index):
		assert 0 <= index < len(self.db)
		del self.db[index]

	def get_names(self):
		return [item[0] for item in self.db]
		
	def save(self):
		fp = open('phonenumber.txt','w')
		for item in self.db:
			fp.write(','.join(item) + '\n')

	def __del__(self):
		print 'phonedb destroy'
			

phonedb = PhoneDB()
if __name__ == '__main__':
	print phonedb
	print phonedb.count
	print phonedb.count()
	phonedb.insert('zz', '1235')
	phonedb.insert('aa', '1235')
	for i, item in enumerate(phonedb.db):
		print 'db[%d] =' % i, item
	print 'ax', phonedb.find_near('ax')
	print 'aa', phonedb.find_near('aa')
	phonedb.save()
