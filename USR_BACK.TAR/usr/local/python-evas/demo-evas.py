import gobject

import evas
from evas import Evas

loop = gobject.MainLoop()


canvas = Evas(240, 320)
print 'create evas'
print dir(evas)
print evas
canvas.a = 5

canvas.image_cache_set(4*1024*1024)
canvas.font_cache_set(1024*1024)
#canvas.font_path_prepend('/home/hwang/opt/share/evas/data')
canvas.font_path_prepend('/usr/local/share/evas/data')

bg = canvas.rectangle()
bg.geometry = 0, 0, 240, 320
bg.layer = -99
bg.color = 0, 0, 80, 255

def key_down_cb(ev):
	print 'key press', ev.keyname
	if ev.keyname == 'q':
		loop.quit()

def key_up_cb(ev):
	print 'key press', ev.keyname

bg.event_callback_add(evas.CALLBACK_KEY_DOWN, key_down_cb)
bg.event_callback_add(evas.CALLBACK_KEY_UP, key_up_cb)
bg.focus_set(True)
bg.show()

rect = canvas.rectangle()
rect.resize(50, 50)
rect.move(100, 100)
rect.color_set(255, 0, 0, 210)
rect.layer_set(5)
print 'rect type = ', rect.type_get()

def cb(event):
	print "movement: out canvas =", event.canvas, 'output =', event.output

rect.event_callback_add(evas.CALLBACK_MOUSE_OUT, cb)
def cb(event):
	print "movement: in"
rect.event_callback_add(evas.CALLBACK_MOUSE_IN, cb)
rect.show()

line = canvas.line()
line.move(150, 150)
line.xy_set(150, 150, 175, 175)
line.color_set(0, 255, 0, 255)
line.show()



grad = canvas.gradient()
grad.resize(100, 100)
grad.move(35, 35)
grad.color_add(10, 20, 30, 180, 20)
grad.color_add(255, 0, 255, 255, 30)
grad.color_add(0, 255, 255, 255, 40)
grad.angle_set(200)

def cb2(event, data):
	print "button: %d with data: %s" % (event.button, data)
grad.event_callback_add(evas.CALLBACK_MOUSE_DOWN, cb2, "some data")
grad.show()
grad.event_callback_del(evas.CALLBACK_MOUSE_DOWN)

poly = canvas.polygon()
poly.color_set(0, 255, 180, 255)
poly.point_add(10, 10)
poly.point_add(80, 80)
poly.point_add(25, 52)
poly.show()
canvas.poly1 = poly
poly.name_set('poly2')

assert poly == canvas.name_find('poly2')

poly.name = 'poly1'
assert 'poly1' == poly.name

assert poly == canvas.name_find('poly1')


text = canvas.text(text='python-evas!', font=('Vera', 24), color=(255, 255, 0, 128))
#text.text_set("python-evas!")
#text.font_set("Vera", 24)
text.font = "Vera", 16
text.text = "Python evas !"
text.move(40, 180)
text.color_set(255, 255, 0, 128)
text.show()

image = canvas.image(image_file='lglogo.png')
print image.size()
image.size_set(320, 240)
image.fill_set(0, 0, 320, 240)
image.show()

canvas.render()

def check_intr_cb():
	return True

gobject.timeout_add(100, check_intr_cb)

text = canvas.time = canvas.text()
text.text_set("python-evas!")
text.font_set("Vera", 12)
text.move(40, 50)
text.show()

def obj_test():
	canvas.poly1.free()
	canvas.poly1 = poly = canvas.polygon()
	import random
	rand = random.Random()
	poly.color_set(0, 255, 180, rand.randint(64, 255))
	poly.point_add(10, 10)
	poly.point_add(80, 80)
	poly.point_add(25, 52)
	poly.show()
	import time
	canvas.time.text_set(time.ctime(time.time()))
	canvas.obscured_clear()
	canvas.obscured_rectangle_add(rand.randint(0, 20), rand.randint(0, 20), rand.randint(200, 400), rand.randint(200, 400))
	canvas.render()
	print 'poly type = ', poly.type_get()
	#loop.quit()
	return True

gobject.timeout_add(100, obj_test)
loop.run()
