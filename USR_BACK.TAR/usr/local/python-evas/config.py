width = 320
height = 240
rotation = 0

idle_font = 'Vera', 18
idle_pos = 160, 65
idle_color = 255, 255, 255, 255
 
connected_font = 'Vera', 18
connected_pos = 160, 65
connected_color = 255, 255, 255, 255

button_font = 'Vera', 16
button_color = 255, 0, 0, 255
left_button_pos = width/4, height - 40
right_button_pos = width/4*3, height - 40

title_pos = 80, 20
title_font = 'Vera', 16
title_color = 255, 255, 255, 255

timer_font = 'Vera', 14
timer_pos = 260, 20
timer_color = 255, 255, 255, 255


Menu1 = 'F1'
Menu2 = 'F2'

OnHook = 'F3'
OffHook = 'F4'

Green = 'F5'
Red = 'F6'
Video = 'F7'
VideoPrivacy = 'F8'
Snapshot = 'F9'
VideoSize = 'F10'



menu_button_pos_x = (10, 10 + 1 * 100, 10 + 2 * 100)
menu_button_pos_y = (50, 40 + 1 * 70)
menu_button_width = 80
menu_button_height = 50
menu_button_color_text_normal = 0, 0, 0, 255
menu_button_color_text_focus = 255, 200, 200, 255
menu_button_color_bg_focus = 0, 0, 0, 255
menu_button_color_bg_normal = 255, 255, 255, 255
menu_button_font = 'Vera', 14


list_pos_x = 50
list_pos_y = 50, 50 + 1 * 35, 50 + 2 * 35, 50 + 3 * 35
list_pos_text_x = 50 + 10
list_pos_text_y = [x + 5 for x in list_pos_y]
list_font = 'Vera', 16
list_width = 250
list_height = 30
list_color_text_normal = 0, 0, 0, 255
list_color_text_focus = 255, 255, 255, 255
list_color_bg_focus = 0, 0, 0, 255
list_color_bg_normal = 255, 255, 255, 255


gauge_pos_x = [50 + i * 30 for i in range(5)]
gauge_pos_y = 180
gauge_width = 25
gauge_height = [20 + i * 10 for i in range(5)]
gauge_color_selected = 255, 50, 50, 255
gauge_color_normal = 155, 50, 50, 128


notify_duration = 3000
notify_font = 'Vera', 14
notify_pos = 160, 50
notify_color = 255, 255, 255, 255


entry_sublabel_pos = 50, 50
entry_sublabel_font = 'Vera', 14
entry_pos = 50, 50 + 50 + 50
entry_color = 0, 0, 0, 255
entry_font = 'Vera', 12
entry_rect_geometry = 40, 40 + 50 + 50, 250, 100 - 50
entry_rect_color = 255, 255, 255, 255


yesno_font = 'Vera', 14
yesno_color = 255, 0, 0, 255
yesno_pos = 50, 50


gallery_geometry = 50, 50, 250, 200
