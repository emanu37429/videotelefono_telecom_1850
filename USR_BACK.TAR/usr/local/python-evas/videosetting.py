
import runtime
from baseui import ListUI
from basemodel import GaugeStage,ListStage, NotifyStage
import setting, status



class VideoQualityStage(GaugeStage):
	title = 'Video Quality'
	def __init__(self):
		GaugeStage.__init__(self, setting.video_quality)

	def activate(self, value):
		print 'video quality set to', value
		setting.set_video_quality(value)
		stage = NotifyStage('Video Quality Set')
		runtime.manager.change_stage(stage)

class VideoDimensionStage(ListStage):
	title = 'Video Dimension'
	choice = ('Remote FullScreen','Remote Small Screen', 'Remote & Local Small')
	def __init__(self):
		ListStage.__init__(self)
		self.ui.set_focus(setting.video_dimension)

	def activate(self, index):
		setting.set_video_dimension(index)
		print 'video dimension set to', index
		stage = NotifyStage('Video Dimension Set')
		runtime.manager.change_stage(stage)

class VideoModeStage(ListStage):
	title = 'Video Mode'
	choice = ('Fast', 'Slow', 'Snapshot')
	def __init__(self):
		ListStage.__init__(self)
		self.ui.set_focus(setting.video_mode)

	def activate(self, index):
		setting.set_video_mode(index)
		print 'video mode set to', index
		stage = NotifyStage('Video Mode Set')
		runtime.manager.change_stage(stage)

class MenuColorStage(ListStage):
	title = 'Menu Color'
	choice = ('Blue', 'Red', 'Green')
	def __init__(self):
		ListStage.__init__(self)
		self.ui.set_focus(setting.menu_color)

	def activate(self, index):
		setting.set_menu_color(index)
		print 'menu color set to', index
		stage = NotifyStage('Menu Color Set')
		runtime.manager.change_stage(stage)

class BackgroundStage(ListStage):
	def __init__(self):
		ListStage.__init__(self)
		self.ui.set_focus(setting.menu_color)

	def activate(self, index):
		setting.menu_color = index
		runtime.manager.change_stage(NotifyStage)
	
class ScreenSaverStage(ListStage):
	def __init__(self):
		ListStage.__init__(self)
		self.ui.set_focus(setting.menu_color)

	def activate(self, index):
		setting.menu_color = index
		runtime.manager.change_stage(NotifyStage)

class ConnectionDetailStage:
	pass

class SnapshotStage:
	pass

class VideoMuteStage:
	def __init__(self):
		setting.toggle_video_mute()
		runtime.manager.queue_backward(2)

_stages = VideoQualityStage, VideoDimensionStage, VideoModeStage, \
	MenuColorStage, BackgroundStage, ScreenSaverStage

_video_stages = VideoMuteStage, VideoQualityStage, SnapshotStage, VideoModeStage,\
	ConnectionDetailStage

def get_stage(index):
	if status.phone_status == status.VideoConnected:
		return _video_stages[index]
	return _stages[index]
