from basemodel import ListStage


class SMSStage(ListStage):
	title = 'SMS'
	choice = ('Write','Received','Personal','Delete')
	def activate(self, index):
		pass

class EmailStage(ListStage):
	title = 'E-Mail'
	choice = ('Write','Personal')
	def activate(self, index):
		pass

class FaxStage(ListStage):
	title = 'Fax'
	choice = ('Write','Personal')
	def activate(self, index):
		pass

class DeleteStage(ListStage):
	title = 'Messages - Delete'
	choice = ('SMS','E-Mail','Fax','Delete All')
	def activate(self, index):
		pass

class SettingStage(ListStage):
	title = 'Settings'
	choice = ('SMS Service','Terminal No.','Service Center')
	def activate(self, index):
		pass

class Servizio404Stage:
	pass
	
_stages = SMSStage, EmailStage, FaxStage, DeleteStage, Servizio404Stage, SettingStage
def get_stage(index):
	return _stages[index]
