

class SetStage:
	pass

class DeleteStage:
	pass

_stages = SetStage, DeleteStage

def get_stage(index):
	return _stages[index]
