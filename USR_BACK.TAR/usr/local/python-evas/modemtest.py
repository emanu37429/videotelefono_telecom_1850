import modem
import gobject

def modem_event(*ev):
	print ev
	etype = ev[0]
	if etype == 'connect':
		print 'connect'
	elif etype == 'disconnect':
		print 'disconnect'
	elif etype == 'dtmf':
		print 'dtmf', ev[1]
	elif etype == 'cid':
		print 'cid', ev[1]
		def idle():
			m.answer()
			return False
		gobject.idle_add(idle)
	elif etype == 'ring':
		print 'ring'

m = modem.Modem(modem_event)
print "%x" % m.modem_flags()
#m.voice_call('5380230,,,,,106')

loop = gobject.MainLoop()
def idle_cb():
	return True
gobject.timeout_add(200, idle_cb)
loop.run()

