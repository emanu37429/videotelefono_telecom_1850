from basemodel import ListStage, NotifyStage, YesNoStage, GaugeStage
import runtime

class MelodyStage(ListStage):
	title = 'Ringer Melody'
	choice = 'Badinerie', 'Jingle Bells', 'Guglielmo Tell', 'Polonaise', 'Xilo'
	def activate(self, index):
		import setting
		setting.ringer_melody = index
		stage = NotifyStage('Ringer Melody\nselected!')
		runtime.manager.change_stage(stage)
		
class VolumeStage(GaugeStage):
	title = 'Ringer Volume'
	def __init__(self):
		GaugeStage.__init__(self, setting.ringer_volume)
	def activate(self, value):
		setting.set_audio_volume(value)
		stage = NotifyStage('Ringer Volume Set')
		runtime.manager.change_stage(stage)

class RingAfterStage(ListStage):
	title = 'Ring After...'
	choice = '1 Ring', '2 Rings', '3 Rings', '4 Rings'

class RingingModeStage(ListStage):
	title = 'Ringing Mode'
	choice = 'Standard', 'Disable', 'First Ring', 'Ring After...'
	notify_messages = 'Standard Mode set!', 'Ring Tone Disabled!', 'Ring Tone Enabled\nafter first ring!'
	def activate(self, index):
		if index in (0, 1, 2):
			stage = NotifyStage(self.notify_messages[index])
			runtime.manager.change_stage(stage)
		else:
			pass
			

class ResNumberFilterStage(YesNoStage):
	def __init__(self):
		if setting.reserved_number_filter:
			message = 'Reserved Number Filter is enabled.\nDo you want to disable?',
		else:
			message = 'Reserved Number Filter is disabled.\nDo you want to enable?',
		def yes_cb():
			setting.toggle_reserved_number_filter()
			if setting.reserved_number_filter:
				message = 'Reserved Number\nFilter Enabled!'
			else:
				message = 'Reserved Number\nFilter Enabled!'
			stage = NotifyStage(message)
			runtime.manager.change_stage(stage)
		def no_cb():
			runtime.manager.back_stage()
		YesNoStage.__init__(self, message,  yes_cb, no_cb, '')

class VIPFilterStage(YesNoStage):
	def __init__(self):
		if setting.reserved_number_filter:
			message = 'VIP Filter is enabled.\nDo you want to disable?',
		else:
			message = 'VIP Filter is disabled.\nDo you want to enable?',
		def yes_cb():
			setting.toggle_vip_filter()
			if setting.vip_filter:
				message = 'Reserved Number\nFilter Enabled!'
			else:
				message = 'Reserved Number\nFilter Disabled!'
			stage = NotifyStage(message)
			runtime.manager.change_stage(stage)
		def no_cb():
			runtime.manager.back_stage()
		YesNoStage.__init__(self, message,  yes_cb, no_cb, '')

_stages = MelodyStage, VolumeStage, RingingModeStage, ResNumberFilterStage, VIPFilterStage

def get_stage(index):
	return _stages[index]
