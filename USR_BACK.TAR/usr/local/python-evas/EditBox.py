# -*- encoding: euc-kr -*-

from evas import *
import gobject

WIN_WIDTH = 320
WIN_HEIGHT = 240

#FONT_PATH = '/home/hwang/opt/share/evas/data'
FONT_PATH = '/usr/local/share/evas/data'
FONT = 'Vera'
FONT_SIZE = 16
LINE_SPACE = 30

class SingleEditBox:
	def __init__(self, evas, width, height):
		self.canvas = evas;

		self.bg= self.canvas.rectangle()
		self.bg.resize(width, height) 
		self.bg.color_set(255, 255, 255, 255) 
		self.bg.event_callback_add(CALLBACK_KEY_DOWN, self.key_input_cb)
		self.bg.event_callback_add(CALLBACK_MOUSE_IN, self.mouse_in)

		self.clip= self.canvas.rectangle()
		self.clip.resize(width, height) 
		self.clip.color_set(255, 255, 255, 255) 

		self.text = self.canvas.text()
		self.text.font_set(FONT, FONT_SIZE)
		self.text.color_set(0, 0, 0, 255)
		self.text.clip_set(self.clip)

		self.cursor = self.canvas.text()
		self.cursor.font_set(FONT, FONT_SIZE)
		self.cursor.color_set(0, 0, 0, 255)
		self.cursor.text_set('_')
		self.cursor_pos = 0
		self.curr_data_idx = 0

		self.max_len = width - FONT_SIZE 
		self.data = ''
		self.show_data()

		#self.focus_set(True)

	def mouse_in(self, event):
		self.focus_set(True)

	def move(self, x, y):
		self.bg.move(x, y)
		self.clip.move(x, y)
		self.text.move(x, y)
		self.cursor.move(x, y)

	def layer_set(self, layer):
		self.bg.layer_set(layer)
		self.text.layer_set(layer)
		self.cursor.layer_set(layer)

	def focus_set(self, focus):
		self.bg.focus_set(focus)

	def show(self):
		self.bg.show()
		self.clip.show()
		self.text.show()
		self.cursor.show()

		self.canvas.render()

	def font_space(self, data, index):
		t = self.canvas.text()
		t.font_set(FONT, FONT_SIZE)
		t.text_set(data[index])	

		print 'in font_space(), index', index, 'data=', data[index], 'width=', t.geometry_get()[2]
		return t.geometry_get()[2]

	def move_cursor(self):
		print 'in move_cursor(), cursor_pos', self.cursor_pos
		offset = 0
		for i in range(abs(self.cursor_pos)):
			offset += self.font_space(self.data, -i)

		pos = self.text.geometry_get()

		print offset
		self.cursor.move(pos[0] + pos[2] - offset, pos[1])

	def show_data(self):
		self.text.text_set(self.data)

		text_len = self.text.geometry_get()[2]		
		print 'in show_data, text_len=', text_len, 'max_len=', self.max_len

		pos = self.bg.geometry_get()
		if text_len > self.max_len:
			offset = text_len - self.max_len
			self.text.move(pos[0] - offset, pos[1])
		else:
			self.text.move(pos[0], pos[1])


	def key_input_cb(self, event):
		if event.keyname == 'BackSpace':
			self.delete_text()
		elif event.keyname == 'Left':
			self.move_cursor_left()
		elif event.keyname == 'Right':
			if self.cursor_pos == 0:
				self.insert_text(' ')
			else:
				self.move_cursor_right()
		elif event.keyname == 'Up':
			self.move_cursor_start()
		elif event.keyname == 'Down':
			self.move_cursor_end()
		else:
			self.insert_text(event.keyname)

		self.show_data()
		self.move_cursor()

	def insert_text(self, txt):
		if self.curr_data_idx < len(self.data):
			self.data = self.data[:self.curr_data_idx] + txt + self.data[self.curr_data_idx:]

		else:
			self.data += txt

		self.curr_data_idx += 1

	def delete_text(self):
		if self.curr_data_idx < len(self.data):
			self.data = self.data[:self.curr_data_idx-1] + self.data[self.curr_data_idx:]
		else:
			self.data = self.data[:-1]

		self.curr_data_idx -= 1

	def get_data(self):
		return self.data

	def move_cursor_left(self):
		if self.curr_data_idx > 0:
			self.curr_data_idx -= 1

		if abs(self.cursor_pos) < len(self.data):
			self.cursor_pos -= 1

	def move_cursor_right(self):
		if self.curr_data_idx < len(self.data):
			self.curr_data_idx += 1

		print 'self.curr_data_idx=', self.curr_data_idx
		if self.cursor_pos <= -1:
			self.cursor_pos += 1

	def move_cursor_start(self):
		self.curr_data_idx = 0	
 		self.cursor_pos = -len(self.data)

	def move_cursor_end(self):
		self.curr_data_idx = len(self.data)
		self.cursor_pos = 0

class MultiEditBox:
	def __init__(self, evas, width, height):
		self.canvas = evas
		self.texts = []

		self.bg= self.canvas.rectangle()
		self.bg.event_callback_add(CALLBACK_KEY_DOWN, self.key_input_cb)
		self.bg.event_callback_add(CALLBACK_MOUSE_IN, self.mouse_in_cb)
		self.bg.event_callback_add(CALLBACK_MOUSE_OUT, self.mouse_out_cb)
		self.bg.resize(width, height) 

		self.cursor = self.canvas.text()
		self.cursor.font_set(FONT, FONT_SIZE)
		self.cursor.color_set(0, 0, 0, 255)
		self.cursor.text_set('_')
		self.cursor_pos = 0
		self.curr_data_idx = 0

		self.curr_line = -1 
		self.max_lines = (height / LINE_SPACE)

		self.make_new_line()

		self.max_len = width - FONT_SIZE
		self.data = ''
		self.show_data()

	def mouse_in_cb(self, event):
		self.focus_set(True)

	def mouse_out_cb(self, event):
		self.focus_set(False)

	def focus_set(self, focus):
		self.bg.focus_set(focus)

	def get_data(self):
		return self.data

	def move(self, x, y):
		self.bg.move(x, y)
		self.cursor.move(x, y)
		self.texts[0].move(x, y)

	def layer_set(self, layer):
		self.bg.layer_set(layer)
		self.cursor.layer_set(layer)
		self.texts[0].layer_set(layer)

	def show(self):
		self.bg.show()
		self.cursor.show()
		self.texts[0].show()

		self.canvas.render()

	def font_space(self, data, index):
		t = self.canvas.text()
		t.font_set(FONT, FONT_SIZE)
		t.text_set(data[index])	

		print 'in font_space(), index', index, 'data=', data[index], 'width=', t.geometry_get()[2]
		return t.geometry_get()[2]

	def make_new_line(self):
		t = self.canvas.text()
		t.text_set('')
		t.font_set(FONT, FONT_SIZE)
		t.color_set(0, 0, 0, 255)

		self.curr_line += 1
		if self.curr_line+1 > self.max_lines:
			print '*** max line over ***'

		self.texts.append(t)
		self.arrange_lines()

	def remove_last_line(self):
		last = self.texts[self.curr_line]
		self.texts.remove(last)
		last.free()
		self.curr_line -= 1
		self.arrange_lines()

	def arrange_lines(self):
		layer = self.texts[0].layer_get()
		pos = self.texts[0].geometry_get()
		m = 0

		print 'in arrange_lines, len(self.texts)=', len(self.texts)
		if len(self.texts) > self.max_lines:
			m = len(self.texts) - self.max_lines
			
		for i in range(len(self.texts)):
			self.texts[i].hide()

		for i in range(len(self.texts) - m):
			self.texts[i+m].layer_set(layer)
			self.texts[i+m].move(pos[0], pos[1] + LINE_SPACE * i)
			self.texts[i+m].show()

	def key_input_cb(self, event):
		if event.keyname == 'BackSpace':
			self.delete_text()
		elif event.keyname == 'Left':
			self.move_cursor_left()
		elif event.keyname == 'Right':
			if self.cursor_pos == 0:
				self.insert_text(' ')
			else:
				self.move_cursor_right()
		elif event.keyname == 'Up':
			self.move_cursor_start()
		elif event.keyname == 'Down':
			self.move_cursor_end()
		else:
			self.insert_text(event.keyname)

		self.show_data()
		self.move_cursor()

	def move_cursor(self):
		print 'in move_cursor(), cursor_pos', self.cursor_pos
		offset = 0
		for i in range(abs(self.cursor_pos)):
			offset += self.font_space(self.data, -i)

		pos = self.texts[self.curr_line].geometry_get()

		print offset
		self.cursor.move(pos[0] + pos[2] - offset, pos[1])

	def show_data(self):
		self.max_chars = 13
		cnt = self.curr_line * self.max_chars 
		data_len = len(self.data)
		display_len = data_len - cnt 
		
		# ������ ������ ���� �ٷ� ���ư��� ���
		if display_len < 0:
			self.remove_last_line()
			display_len = self.max_chars + display_len

		# ���ο� ������ �߰��Ǿ� �� ��� 	
		elif display_len > self.max_chars:
			print 'over'
			old = self.texts[self.curr_line].text_get()
			self.texts[self.curr_line].text_set(old[:-1])

			self.make_new_line()
			display_len = display_len - self.max_chars


		if display_len == 0:
			#self.texts[self.curr_line].text_set('_')
			self.texts[self.curr_line].text_set('')
		else :
			#self.texts[self.curr_line].text_set(self.data[-(display_len):] + '_')
			self.texts[self.curr_line].text_set(self.data[-(display_len):])

	def insert_text(self, txt):
		if self.curr_data_idx < len(self.data):
			self.data = self.data[:self.curr_data_idx] + txt + self.data[self.curr_data_idx:]
		else:
			self.data += txt

		self.curr_data_idx += 1

	def delete_text(self):
		if self.curr_data_idx < len(self.data):
			self.data = self.data[:self.curr_data_idx-1] + self.data[self.curr_data_idx:]
		else:
			self.data = self.data[:-1]

		self.curr_data_idx -= 1

	def move_cursor_left(self):
		if self.curr_data_idx > 0:
			self.curr_data_idx -= 1

		if abs(self.cursor_pos) < len(self.data):
			self.cursor_pos -= 1

	def move_cursor_right(self):
		if self.curr_data_idx < len(self.data):
			self.curr_data_idx += 1

		print 'self.curr_data_idx=', self.curr_data_idx
		if self.cursor_pos <= -1:
			self.cursor_pos += 1

	def move_cursor_up(self):
		if self.curr_line > 0:
			self.curr_line -= 1
		else:
			self.curr_data_idx = 0	
 			self.cursor_pos = -len(self.data)

	def move_cursor_down(self):
		if self.curr_line < len(self.texts):
			self.curr_line += 1
		else:
			self.curr_data_idx = len(self.data)
			self.cursor_pos = 0


if __name__ == "__main__":

	loop = gobject.MainLoop()

	evas = Evas(WIN_WIDTH, WIN_HEIGHT)
	evas.image_cache_set(4*1024*1024)
	evas.font_cache_set(1024*1024)
	evas.font_path_prepend(FONT_PATH)

	bg = evas.rectangle()
	bg.resize(WIN_WIDTH, WIN_HEIGHT)
	bg.move(0, 0)
	bg.layer_set(-99)
	bg.color_set(0, 0, 255, 255)
	bg.show()

	edit1 = SingleEditBox(evas, 200, 30)
	edit1.move(10, 20)
	edit1.layer_set(0)
	edit1.show()

	edit2 = MultiEditBox(evas, 200, 100)
	edit2.move(10, 70)
	edit2.layer_set(0)
	edit2.show()

	evas.render()

	def check_intr_cb():
		return True

	gobject.timeout_add(100, check_intr_cb)
	loop.run()
