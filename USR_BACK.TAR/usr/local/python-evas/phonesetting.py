from basemodel import ListStage, GaugeStage, NotifyStage
import setting, runtime


class RingerStage(ListStage):
	title = 'Ringer'
	choice = 'Ringer Melody', 'Ringer Volume','Ringing Mode','Res.Number Filter'
	def activate(self, index):
		import ringer
		stage = ringer.get_stage(index)
		runtime.manager.stack_stage(stage)

class AudioVolumeStage(GaugeStage):
	title = 'Audio Volume'
	def __init__(self):
		GaugeStage.__init__(self, setting.audio_volume)

	def activate(self, value):
		setting.set_audio_volume(value)
		stage = NotifyStage('Audio Volume Set')
		runtime.manager.change_stage(stage)

class DateStage:
	pass

class PABXAccessCodeStage:
	pass

class InterdigitPauseStage:
	pass

class CallBarringStage:
	pass

class LanguageStage:
	pass

class PINStage:
	pass

class RestoreStage:
	pass

class SettingsStage:
	pass

_stages = RingerStage, AudioVolumeStage, DateStage, PABXAccessCodeStage, InterdigitPauseStage, \
	CallBarringStage, LanguageStage, PINStage, RestoreStage, SettingsStage
def get_stage(index):
	return _stages[index]
