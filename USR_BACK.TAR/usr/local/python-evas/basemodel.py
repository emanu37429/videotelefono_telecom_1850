import config
import baseui
import gobject
import runtime

class Stage:
	def destroy(self):
		self.ui.destroy()

	def show(self):
		self.ui.show()

	def hide(self):
		self.ui.hide()

	def handle_key(self, down, keyname):
		return False

	def handle_modem(self, command):
		return False

class ListStage(Stage):
	def __init__(self,choice=None,title=None):
		if title == None:
			title = self.title
		if choice == None:
			choice = self.choice
		self.ui = baseui.ListUI('Ok', 'Back', title)
		self.ui.set_list(choice)
		self.ui.show()

	def handle_key(self, down, keyname):
		if not down:
			return False
		if keyname == config.Menu1:
			# OK
			print 'message: current selection', self.ui.get_focus()
			self.activate(self.ui.get_focus())
			return True
		elif keyname == config.Menu2:
			# Back
			runtime.manager.back_stage()
			return True
		elif keyname in ('Up', 'Down'):
			self.ui.handle_key(down, keyname)

		return False


class GaugeStage(Stage):

	def __init__(self, value, title=None):
		if title == None:
			title = self.title
		self.ui = baseui.GaugeUI('Ok', 'Back', title)
		self.ui.set_value(value)
		self.ui.show()

	def handle_key(self, down, keyname):
		if not down:
			return False
		if keyname == config.Menu1:
			self.activate(self.ui.get_value())
		elif keyname == config.Menu2:
			# Back
			runtime.manager.back_stage()
		elif keyname in ('Up', 'Down'):
			self.ui.handle_key(down, keyname)
		else:
			return False
		return True

class YesNoStage(Stage):
	def __init__(self, message, yes_cb, no_cb, title):
		self.ui = baseui.YesNoUI(title, message)
		self.ui.show()
		self.yes_cb = yes_cb
		self.no_cb = no_cb

	def handle_key(self, down, keyname):
		if not down:
			return False
		if keyname == config.Menu1:
			print 'Ok'
			self.yes_cb()
		elif keyname == config.Menu2:
			print 'No'
			self.no_cb()
		else:
			return False
		return True


class EntryStage(Stage):
	def __init__(self, sub_label, title, left='Ok', right='Back'):
		self.ui = baseui.EntryUI(left, right, title, sub_label)
		self.ui.show()

	def activate_menu2(self):
		runtime.manager.back_stage()

	def handle_key(self, down, keyname):
		if not down:
			return False
		if keyname == config.Menu1:
			print 'Left Menu'
			self.activate_menu1()
		elif keyname == config.Menu2:
			print 'Right Menu'
			if self.ui.get_text():
				self.ui.delete_char()
				if not self.ui.get_text():
					self.ui.set_right('Back')	
			else:
				self.activate_menu2()
		else:
			ret = self.ui.handle_key(down, keyname)
			if self.ui.get_text():
				self.ui.set_right('Delete')
		return True
		
class NotifyStage(Stage):
	def __init__(self, message, cb=None):
		self.ui = baseui.NotifyUI(message)
		self.ui.show()
		def destroy():
			runtime.manager.back_stage()
			return False
		cb = cb or destroy
		self.destroy_tag = gobject.timeout_add(config.notify_duration, cb)

