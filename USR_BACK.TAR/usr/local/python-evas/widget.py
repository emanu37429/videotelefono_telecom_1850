
"""
screen
  -> progressbar
  -> video call
  -> volume bar
  -> list
  -> idle
  -> voice connected
  -> number editing
  -> name editing
  -> message notify
"""

"""
base:
   title
   {left, right} button label:


idle
head

button
label
entry
text
list item
Base

voice connected

number editing

name editing

message editing

message notify

progressbar

video call

choose list

volume bar

"""

import config, runtime

class Widget:
	def hide(self):
		for w in self.children:
			w.hide()

	def show(self):
		for w in self.children:
			w.show()

	def free(self):
		for w in self.children:
			w.free()


class List(Widget):
	def __init__(self, labels):
		self.labels = labels
		self.top_index = 0
		self.children = []
		self.items = []
		self.focus = -1
		x = config.list_pos_x
		print self.labels
		nrow = min(len(self.labels), len(config.list_pos_y))
		print 'nrow = ',nrow
		for i in range(nrow):
			y = config.list_pos_y[i]
			r = runtime.canvas.rectangle(pos=(x, y), size=(config.list_width, config.list_height))
			r.color = config.list_color_bg_normal
			t = runtime.canvas.text(text=labels[i],font=config.list_font) 
			t.pos = config.list_pos_text_x, config.list_pos_text_y[i]
			t.color = config.list_color_text_normal
			self.items.append((r, t))
			self.children.append(r)
			self.children.append(t)
		self.set_focus(0)


	def set_focus(self, focus):
		print 'set focus', focus
		if self.focus == focus:
			return
		if self.focus >= 0:
			r, t = self.items[self.focus - self.top_index]
			r.color = config.list_color_bg_normal
			t.color = config.list_color_text_normal

		hi_index = focus - self.top_index
		if hi_index < 0 or len(config.list_pos_y) <= hi_index:
			if hi_index < 0:
				self.top_index += hi_index
			else:
				self.top_index += len(config.list_pos_y) - hi_index + 1
			for i in range(len(config.list_pos_y)):
				r, t = self.items[i]
				t.text = self.labels[self.top_index + i]
					
		self.focus = focus
		r, t = self.items[focus - self.top_index]
		r.color = config.list_color_bg_focus
		t.color = config.list_color_text_focus
			
	def focus_up(self):
		if self.focus > 0:
			self.set_focus(self.focus - 1)

	def focus_down(self):
		if self.focus < len(self.labels) - 1:
			self.set_focus(self.focus + 1)

	def set_text(self, n, text):
		self.labels[n] = text
		vindex = n - self.top_index
		if 0 <= vindex < len(config.list_pos_y):
			r, t = self.items[vindex]
			t.text = text

	def change_language(self):
		pass
		

class Gauge(Widget):
	def __init__(self):
		self.rects = []
		self.value = -1

		for i in range(len(config.gauge_pos_x)):
			x = config.gauge_pos_x[i]
			w = config.gauge_width
			h = config.gauge_height[i]
			y = config.gauge_pos_y - h
			rect = runtime.canvas.rectangle(pos=(x,y), size=(w,h))
			self.rects.append(rect)
		self.set_value(0)
		self.children = self.rects

	def value_up(self):
		if self.value < len(config.gauge_pos_x):
			self.set_value(self.value + 1)

	def value_down(self):
		if self.value > 0:
			self.set_value(self.value - 1)

	def set_value(self, value):
		if value == self.value:
			return
		for i in range(0, value):
			self.rects[i].color = config.gauge_color_selected
		for i in range(value, len(config.gauge_pos_x)):
			self.rects[i].color = config.gauge_color_normal
		self.value = value

	def get_value(self):
		return self.value
			
class Entry(Widget):
	def __init__(self):
		self.text = ''
		self.rect = runtime.canvas.rectangle()
		self.rect.geometry = config.entry_rect_geometry
		self.rect.color = config.entry_rect_color

		self.editor = runtime.canvas.text(font=config.entry_font)
		self.editor.color = config.entry_color
		self.editor.pos = config.entry_pos
		self.editor.text = self.text
		self.children = self.rect, self.editor

	def insert(self, text):
		self.text = self.text + text
		self.editor.text = self.text

	def set_text(self, text):
		self.text = text
		self.editor.text = self.text


class Label(Widget):
	# center aligned multi-line text
	def __init__(self, text, font, pos, color):
		self.pos = pos
		self.color = color
		self.font = font
		self.children = []
		self.set_text(text)

	def set_text(self, text):
		print 'set text', text
		self.free()
		lines = text.split('\n')
		x, y = self.pos
		for line in lines:
			text = runtime.canvas.text(text=line, font=self.font,color=self.color)
			text.pos = x - text.geometry[2]/2, y
			self.children.append(text)
			y += text.geometry[3]
		if text:
			self.show()

	def set_color(self, color):
		for w in self.children:
			w.color = color

	def change_language(self):
		pass

class MenuButton(Widget):
	def __init__(self, text, x, y):
		w, h = config.menu_button_width, config.menu_button_height
		rect = runtime.canvas.rectangle(pos=(x, y), size=(w, h))
		rect.color = config.menu_button_color_bg_normal 
		text = Label(text,font=config.menu_button_font,pos=(x+w/2,y),color=config.menu_button_color_text_normal)
		self.children = rect, text

	def change_language(self):
		self.children[1].change_language()
