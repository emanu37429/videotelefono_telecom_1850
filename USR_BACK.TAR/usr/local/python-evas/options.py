# options

import status, runtime
from basemodel import ListStage

def PhoneBookStage():
	import model
	return model.PhoneBookStage()

class MuteStage:
	pass

def AudioVolumeStage():
	import phonesetting
	return phonesetting.AudioVolumeStage()

class WaitingStage:
	pass

class FlashStage:
	pass

class VideoOptionStage(ListStage):
	title = 'Video Options'
	choice = 'Privacy', 'Video Quality', 'Snapshot', 'Video Mode'
	def __init__(self):
		ListStage.__init__(self)
		if setting.video_mute:
			self.ui.set_text(0, 'Disable Privacy')

	def activate(self, index):
		import videosetting
		stage = videosetting.get_stage(index)
		runtime.manager.stack_stage(stage)

class SaveStage:
	pass

class PreDialOptionsStage(ListStage):
	title = 'Pre-Dialling Options'
	choice = 'Save', 'Hide Number', 'Insert Pause', 'Flash R'
	def activate(self, index):
		if index == 1:
			# insert Pause
			status.set_dial_number('*67#' + status.dial_number)
			runtime.manager.back_stage()
			return
		if index == 2:
			# insert Pause
			status.set_dial_number(status.dial_number + 'P')
			runtime.manager.back_stage()
			return
		if index == 3:
			# insert Pause
			status.set_dial_number(status.dial_number + 'R')
			runtime.manager.back_stage()
			return
		if index == 0:
			stage = SaveStage
			runtime.manager.stack_stage(stage)

_analog_stages = PhoneBookStage, MuteStage, AudioVolumeStage, WaitingStage, FlashStage
_video_stages = PhoneBookStage, VideoOptionStage, MuteStage, AudioVolumeStage, WaitingStage

def get_stage(index):
	if status.phone_status == status.VoiceConnected:
		return _analog_stages[index]
	elif status.phone_status == status.VideoConnected:
		return _video_stages[index]
	else:
		return _predial_stages[index]
