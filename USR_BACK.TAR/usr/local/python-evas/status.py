
phone_hook = True

Disconnected = 0
VoiceConnected = 1
VideoConnected = 2
Dialing = 3

phone_status = Disconnected

def set_hook(hook):
	global phone_hook
	phone_hook = hook


editing_phone_number_index = -1
editing_phone_item =[''] * 9

class _PhoneItem:
	def __init__(self):
		self.reset()
	def reset(self):
		self.name = self.number = self.mobile = \
		self.email = self.fax = self.tone = self.vip = \
		self.call_type = self.snapshot = ''

phone_item = _PhoneItem()

dial_number = ''
def set_dial_number(num):
	global dial_number
	dial_number = num
caller_number = ''

def set_connected_duration(dur):
	global connected_duration
	connected_duration = dur
connected_duration = -1
