
manager = None
canvas = None

lb = None
rb = None
title = None
timer = None
timer_tag = 0
