
screen_saver_delay = -1
video_dimension = 0
video_quality = 0
video_mode = 0
menu_color = 0
video_mute = False

audio_volume = 0

def set_video_quality(quality):
	global video_quality
	video_quality = quality

def set_video_dimension(dim):
	global video_dimension
	video_dimension = dim

def set_menu_color(color):
	global menu_color
	menu_color = color

def set_video_mode(mode):
	global video_mode
	video_mode = mode

def toggle_video_mute():
	global video_mute
	video_mute = not video_mute

def set_audio_volume(vol):
	global audio_volume
	audio_volume = vol

ringer_melody = 0
ringer_volume = 0

def set_ringer_volume(vol):
	global ringer_volume
	ringer_volume = vol
def set_ringer_melody(melody):
	global ringer_melody
	ringer_melody = melody

vip_filter = False
reserved_number_filter = False

def toggle_vip_filter():
	global vip_filter
	vip_filter = not vip_filter

def toggle_reserved_number_filter():
	global reserved_number_filter
	reserved_number_filter = not reserved_number_filter


