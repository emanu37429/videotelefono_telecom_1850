/************************************************************************/
/*									*/
/*			 Copyright (C) 1990-2005			*/
/*			    Loquendo SpA				*/
/*			  All Rights Reserved				*/
/*									*/
/************************************************************************/

/************************************************************************/
/*									*/
/*		       VERSION FILE FOR LOQUENDO TTS			*/
/*									*/
/************************************************************************/
#if !defined tts_H_VERSION_INCLUDED
#define tts_H_VERSION_INCLUDED

//#define ELQ_MULTIMEDIA

#if defined ELQ_MULTIMEDIA
#define ttsPRODUCTNAME "LoquendoTTS Multimedia"
#else
#define ttsPRODUCTNAME "LoquendoTTS"
#endif /* ELQ_MULTIMEDIA */
#define ttsINTERNALNAME "LTTS"
#define ttsVERSION "6"
#define ttsSUBVERSION "6"

#if defined _WIN32_WCE || defined __SYMBIAN32__
#define ttsRCVERSION 6,6,5,0
#define ttsRCVERSIONSTRING "6, 6, 5, 0\0"
#define ttsBUILD "20051129"
#else
#define ttsRCVERSION 6,6,5,0
#define ttsRCVERSIONSTRING "6, 6, 5, 0\0"
#define ttsBUILD "20051129"
#endif /* _WIN32_WCE */

#endif
