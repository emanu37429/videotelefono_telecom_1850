/************************************************************************/
/*									*/
/*			 Copyright (C) 1990-2003			*/
/*			    Loquendo SpA				*/
/*			  All Rights Reserved				*/
/*									*/
/************************************************************************/

/************************************************************************/
/*									*/
/*			    LOQUENDO TTS API				*/
/*									*/
/************************************************************************/

#if !defined tts_H_INCLUDED
#define tts_H_INCLUDED

#include <string.h>
#include "ttsversion.h"

#if !defined __SYMBIAN32__
#define EXPORT_C
#define IMPORT_C
#endif

#if defined __SYMBIAN32__

#include <stdlib.h>	/* for wchar_t */
#define tts_API_DEFINITION
#define tts_API_DEFINITION_P *
#define tts_CLASS_DEFINITION

#elif defined _WIN32

#define WIN32_LEAN_AND_MEAN
#include <windows.h>

#if defined ttsINCLUDEDBYTHEDLL || defined STATIC_LIB || defined INCLUDE_STATIC_LIB
#define tts_API_DEFINITION __declspec(dllexport) _stdcall
#define tts_API_DEFINITION_P __declspec(dllexport) * __stdcall
#define tts_CLASS_DEFINITION __declspec(dllexport)
#else 
#define tts_API_DEFINITION __declspec(dllimport) _stdcall
#define tts_API_DEFINITION_P __declspec(dllimport) * _stdcall
#define tts_CLASS_DEFINITION __declspec(dllimport)
#endif // INCLUDEDBYTHEDLL || STATIC_LIB

#elif unix
#include <stdlib.h>	/* for wchar_t */
#define tts_API_DEFINITION
#define tts_API_DEFINITION_P *
#define tts_CLASS_DEFINITION
#endif /* _WIN32 */

/* session or instance handle */
typedef void *ttsHandleType;

/* booleans */
typedef unsigned char ttsBoolType;  /* bool and BOOL replacement	*/
#define ttsTRUE	    1u		    /* true and TRUE replacement	*/
#define ttsFALSE    0u		    /* false and FALSE replacement	*/

#define tts_NO_PROC		0
#define tts_GET_VERSION		1
#define tts_USERFUNC		2

/* error handling */
typedef unsigned long ttsResultType;    /* error code type definition	*/
#define tts_SevereError(code) ((code) >= 0xC0000000ul)
#define tts_OK		    0L		/* everything is ok: no error	    */

/* pointer functions stuff for dynamic loading */
typedef ttsResultType (*ttspFuncType) (void);
typedef int ttsProcIdType;
typedef ttsResultType (*ttsGetVersionType) (char * Version);
typedef ttspFuncType (*ttsGetProcTableAddrType)(ttsProcIdType procname, const void *pUser);
#if defined TTSINCLUDED_BY_AUDIODEST || !defined _WIN32
#define ttsGetProcTableAddrPointerType ttsGetProcTableAddrType
#else // !defined TTSINCLUDED_BY_AUDIODEST && defined _WIN32
#define ttsGetProcTableAddrPointerType __declspec(dllimport) ttsGetProcTableAddrType
#endif //

/* ttsRead */
#define TTSDEFAULT	0
/* ttsRead: InputType */
#define TTSBUFFER	1
#define TTSFILE		2
/* ttsRead: Processing mode */
#define TTSNONBLOCKING	1
#define	TTSBLOCKING	2
#define TTSSLICE	3
/* ttsRead: TextCoding */
#define TTSANSI		1
#define TTSISO		2
#define TTSUNICODE	3
#define TTSUTF8		4
/* ttsRead: InputMode (ex. Reading mode) */
#define TTSMULTILINE	1
#define TTSPARAGRAPH	2
#define TTSSSML		3
#define TTSXML		4
/* per entrambi i precedenti: */
#define TTSAUTODETECT	10

/* ttsSkip */
#define TTS_SENTENCE	    0
#define	TTS_PROMPT	    1
#define TTS_GOTOSENTENCE    2
/* ttsPhoneticUtils */
#define	TTS_PHONEMEMNEMONIC			0 
#define	TTS_GETPHONETICSTREAM			1
#define	TTS_LOQUENDOPHONEME2IPA			2
#define	TTS_IPASTRING2IPACODE			3
#define	TTS_GETPHONEMESNUMBER			4
#define	TTS_IPACODE2IPASTRINGREDUCED		5
#define	TTS_REASONABLEPHOMNEMONIC		6

/* audio destination */
#define TTS_AUDIOFULL -1

/* events */
#define	TTSEVT_BOOKMARK 0
#define	TTSEVT_DATA 1
#define	TTSEVT_AUDIOSTART 2
#define	TTSEVT_ENDOFSPEECH 3
#define	TTSEVT_FREESPACE 4
#define	TTSEVT_OVERFLOW 5
#define	TTSEVT_ERROR 6
#define	TTSEVT_PAUSE 7
#define	TTSEVT_RESUME 8
#define	TTSEVT_POSITION 9
#define	TTSEVT_TAG 10
#define	TTSEVT_NOTSENT 11
#define	TTSEVT_PHONEMES 12
#define TTSEVT_DEBUG 13
#define TTSEVT_WORDTRANSCRIPTION 14
#define TTSEVT_TEXT 15
#define TTSEVT_SENTENCE 16
#define TTSEVT_AUDIO 17
#define TTSEVT_VOICECHANGE 18
#define TTSEVT_LANGUAGECHANGE 19
#define TTSEVT_RESERVED 100

#define TTSAUDIO_OPEN		    (tts_USERFUNC)
#define TTSAUDIO_CLOSE		    (tts_USERFUNC + 1)
#define TTSAUDIO_PUTDATA	    (tts_USERFUNC + 2)	
#define TTSAUDIO_STOP		    (tts_USERFUNC + 3)
#define TTSAUDIO_PAUSE		    (tts_USERFUNC + 4)
#define TTSAUDIO_RESUME		    (tts_USERFUNC + 5)
#define TTSAUDIO_GETERRORMESSAGE    (tts_USERFUNC + 6)
#define TTSAUDIO_CUSTOMOPEN	    (tts_USERFUNC + 7)

typedef ttsResultType (*ttsAudioOpenType)(void **channel,const char *specification, unsigned int SampleRate,const char *coding,ttsBoolType *bRealTime);
typedef ttsResultType (*ttsAudioCloseType)(void *channel);
typedef ttsResultType (*ttsAudioPutDataType)(void *channel,void *pData,unsigned int nBytes,unsigned int *nSent);
typedef ttsResultType (*ttsAudioStopType)(void *channel);
typedef ttsResultType (*ttsAudioPauseType)(void *channel);
typedef ttsResultType (*ttsAudioResumeType)(void *channel);
typedef ttsResultType (*ttsAudioGetErrorMessageType)(ttsResultType ErrorCode,char *message,unsigned int size);
typedef ttsResultType (*ttsAudioCustomOpenType)(void **channel,const char *specification, unsigned int SampleRate,const char *coding,ttsBoolType *bRealTime, const void *pUser);

#define ttsSTRINGMAXLEN 512

typedef char ttsInfoStringType[ttsSTRINGMAXLEN];

typedef struct {
    void *buffer;			/* PCM buffer			    */
    unsigned long size;			/* PCM buffer size in bytes	    */
    unsigned long ipacode;		/* current phoneme IPA code 	    */
    unsigned long NBytes;		/* current phoneme size in bytes    */
    unsigned short DurationMs;		/* duration in msec		    */
    unsigned char bValid;		/* current phoneme is complete	    */
    char tag[ttsSTRINGMAXLEN];		/* optional tag for current phoneme */
} ttsPhonInfoType;

#ifdef __SYMBIAN32__
    #define TTSCALLBACK
#elif defined _WIN32
    #define TTSCALLBACK CALLBACK
#else
    #define TTSCALLBACK
#endif

#define TTSCALLBACKFUNCTION 0
#define TTSCALLBACKWINDOW 1
#define TTSCALLBACKEVENT 2
#define TTSCALLBACKAUDIO 3

typedef long (*ttsOutputFunctionType) (void *data, void *destination);
typedef long ttsEventType;
typedef void *ttsCallbackType;
typedef void (TTSCALLBACK *ttsCallbackFunctionType)(
    ttsEventType nReason,
    void *lData,
    void *pUser
);

/* log levels */
#define tts_LOGLEVEL 1
#define tts_TRACELEVEL 2
#define tts_EXTLOGLEVEL 4
#define tts_RESERVEDLOGLEVEL 8
#define tts_62ORMORE 0x80000000

#if defined __cplusplus
extern "C" {
#endif /* __cplusplus */

ttsResultType tts_API_DEFINITION ttsRead(
    ttsHandleType hInstance, 
    const void *Input, 
    int InputType,
    int TextCoding, 
    int ReadingMode, 
    int ProcessingMode
    );

ttsResultType tts_API_DEFINITION ttsPause(
    ttsHandleType hInstance
    );

ttsResultType tts_API_DEFINITION ttsResume(
    ttsHandleType hInstance
    );

ttsResultType tts_API_DEFINITION ttsSkip(
    ttsHandleType hInstance,
    unsigned int Type,
    signed int NChunks
    );

ttsBoolType tts_API_DEFINITION ttsDone(
    ttsHandleType hInstance
    );

ttsResultType tts_API_DEFINITION ttsStop(
    ttsHandleType hInstance
    );

ttsResultType tts_API_DEFINITION ttsSetDefaultAttributes(
    ttsHandleType hInstance
    );

unsigned int tts_API_DEFINITION ttsSpeakerLanguage(
    ttsHandleType session,
    const char *Speaker,
    ttsInfoStringType Language,
    ttsInfoStringType SubLanguage
);

unsigned int tts_API_DEFINITION ttsGetLanguage(
    ttsHandleType hInstance,
    ttsInfoStringType Language,
    ttsInfoStringType SubLanguage
);

ttsResultType tts_API_DEFINITION ttsAudioFreeSpace(
    ttsHandleType hInstance,
    ttsBoolType *bFreeSpace
    );

ttsResultType tts_API_DEFINITION ttsNewLexicon(
    ttsHandleType *hLexicon,
    ttsHandleType hVoice,
    const char *filename
);

ttsResultType tts_API_DEFINITION ttsDeleteLexicon(
    ttsHandleType hLexicon
);

ttsResultType tts_API_DEFINITION ttsSetSpeed(
    ttsHandleType hInstance,
    unsigned int value
    );

ttsResultType tts_API_DEFINITION ttsSetPitch(
    ttsHandleType hInstance,
    unsigned int value
    );

ttsResultType tts_API_DEFINITION ttsSetPitchRange(
    ttsHandleType hInstance,
    unsigned int minimum,
    unsigned int normal,
    unsigned int maximum
    );

ttsResultType tts_API_DEFINITION ttsGetPitchRange(
    ttsHandleType hInstance,
    unsigned int *minimum,
    unsigned int *normal,
    unsigned int *maximum
    );
ttsResultType tts_API_DEFINITION ttsSetSpeedRange(
    ttsHandleType hInstance,
    unsigned int minimum,
    unsigned int normal,
    unsigned int maximum
    );

ttsResultType tts_API_DEFINITION ttsGetSpeedRange(
    ttsHandleType hInstance,
    unsigned int *minimum,
    unsigned int *normal,
    unsigned int *maximum
    );

ttsResultType tts_API_DEFINITION ttsSetVolumeRange(
    ttsHandleType hInstance,
    unsigned int minimum,
    unsigned int normal,
    unsigned int maximum
    );

ttsResultType tts_API_DEFINITION ttsGetVolumeRange(
    ttsHandleType hInstance,
    unsigned int *minimum,
    unsigned int *normal,
    unsigned int *maximum
    );

ttsResultType tts_API_DEFINITION ttsGetPitch(
    ttsHandleType hInstance,
    unsigned int *value
    );


ttsResultType tts_API_DEFINITION ttsGetSpeed(
    ttsHandleType hInstance,
    unsigned int *value
    );

ttsResultType tts_API_DEFINITION ttsGetActiveVoice(
    ttsHandleType hInstance,
    ttsInfoStringType Speaker,
    unsigned int *SampleRate,
    ttsInfoStringType Coding
    );

ttsResultType tts_API_DEFINITION ttsNewVoice(
    ttsHandleType *pvv,
    ttsHandleType hInstance,
    const char *Speaker,
    unsigned int SampleRate, 
    const char *coding
    );

ttsResultType tts_API_DEFINITION ttsDeleteVoice(
    ttsHandleType voice
    );

ttsResultType tts_API_DEFINITION ttsActivateVoice(
    ttsHandleType voice
    );

ttsResultType tts_API_DEFINITION ttsRegisterCallback(
    ttsHandleType hInstance,
    ttsCallbackType pCallback,
    void *pUser,
    unsigned long Type
    );

ttsResultType tts_API_DEFINITION ttsGetLexiconEntry(
    ttsHandleType hLexicon,
    const char * string,
    ttsInfoStringType trascription
);

ttsResultType tts_API_DEFINITION ttsGetVersionInfo(
    ttsInfoStringType StrVer
    );

char tts_API_DEFINITION_P ttsFullName(
    ttsInfoStringType fullname,
    const char * path,
    const char * name
    );

char tts_API_DEFINITION_P ttsGetError(
    ttsHandleType handle
);

ttsBoolType tts_API_DEFINITION ttsTestVoice(
    ttsHandleType session,    /* identificativo sessione		*/
    const char * Speaker,
    unsigned int FreqCamp,
    const char * Codifica
    );

ttsResultType tts_API_DEFINITION ttsInject(
    ttsHandleType hInstance,
    const char * command
    );

ttsResultType tts_API_DEFINITION ttsGetExamples(ttsHandleType hinstance,char **buffer);

ttsResultType tts_API_DEFINITION ttsPhoneticTranscription(
    ttsHandleType hInstance,
    const void * GraphemeString,
    void *PhonemeString,
    unsigned long *duration,
    int TextCoding,
    int ReadingMode
);

ttsResultType tts_API_DEFINITION ttsRemoveLexiconEntry(
    ttsHandleType hLexicon,
    const char * string
    );

ttsResultType tts_API_DEFINITION ttsAddLexiconEntry(
    ttsHandleType hLexicon,
    const char * string,
    const char * transcription
);

ttsResultType tts_API_DEFINITION ttsSaveLexicon(
    ttsHandleType hLexicon,
    const char * filename
);

ttsResultType tts_API_DEFINITION ttsSetAudio(
    ttsHandleType hInstance,
    const char *AudioDestName, 
    const char *AudioDeviceName, 
    const char *coding,
    const void *pUser
    );

ttsResultType tts_API_DEFINITION ttsGetDescription(
    ttsHandleType session,
    const char *Speaker,
    ttsInfoStringType description
);

unsigned int tts_API_DEFINITION ttsQuery(
    ttsHandleType Handle,
    const char *SelectedData,
    const char *DataConditions,
    char *QueryResult,
    unsigned int QueryResultLen,
    ttsBoolType SearchInSystem
);

ttsResultType tts_API_DEFINITION ttsSetVolume(
    ttsHandleType hInstance,
    unsigned int volume
);

ttsResultType tts_API_DEFINITION ttsGetVolume(
    ttsHandleType hInstance,
    unsigned int *volume
);

ttsResultType tts_API_DEFINITION ttsSetOutput(
    ttsHandleType hInstance,
    const char *module,
    ttsOutputFunctionType pfunc,
    void *destination
);

ttsResultType tts_API_DEFINITION ttsSetModularStructure(
    ttsHandleType hInstance,
    const char *head,
    const char *tail,
    void *source
);

ttsResultType tts_API_DEFINITION ttsValidateXML(
    ttsHandleType hInstance,
    const void *Input,
    int InputType,
    int TextCoding
);

ttsResultType tts_API_DEFINITION ttsSSMLConvert(
    ttsHandleType hInstance,
    const void *Input,
    char **Output,
    int InputType,
    int TextCoding
);

void tts_API_DEFINITION ttsFreeBuffer(void *buf);

ttsResultType tts_API_DEFINITION ttsNewSession(
    ttsHandleType *hSession,
    const char *IniFile
);

ttsResultType tts_API_DEFINITION ttsDeleteSession(
    ttsHandleType hSession
);

ttsResultType tts_API_DEFINITION ttsNewInstance(
    ttsHandleType *hInstance,
    ttsHandleType hSession,
    const char *IniFile
);

ttsResultType tts_API_DEFINITION ttsDeleteInstance(
    ttsHandleType hInstance
);

ttsResultType tts_API_DEFINITION ttsLanguageGuess(
    ttsHandleType hInstance,
    const void *Input,
    int InputType,
    int TextCoding,
    int ReadingMode,
    ttsInfoStringType GuessedLanguage
);

ttsResultType tts_API_DEFINITION ttsSetInstanceParam(
    ttsHandleType hInstance,
    const char * paramName,
    const char * paramValue
);

ttsResultType tts_API_DEFINITION ttsGetInstanceParam(
    ttsHandleType hInstance,
    const char * paramName,
    ttsInfoStringType paramValue
);

ttsResultType tts_API_DEFINITION ttsGetSessionParam(
    ttsHandleType hSession,
    const char * paramName,
    ttsInfoStringType paramValue
);

ttsResultType tts_API_DEFINITION ttsSaveConfigurationParam(
    const char * area,
    const char * key,
    const char * value
);

ttsResultType tts_API_DEFINITION ttsLoadConfigurationParam(
    const char * area,
    const char * key,
    ttsInfoStringType value
);

ttsResultType tts_API_DEFINITION ttsDeleteConfiguration(
    const char * area
);

unsigned long tts_API_DEFINITION ttsPhoneticUtils(
    unsigned long utility,
    ...
);

ttsResultType tts_API_DEFINITION ttsSetForeignLanguage(
    ttsHandleType hInstance,
    const char *ForeignLanguage
);

ttsResultType tts_API_DEFINITION ttsCheckPhoneticTranscription(
    ttsHandleType hInstance,
    const char *PhoneticString
);

ttsResultType tts_API_DEFINITION ttsClaimLicense(
    ttsHandleType hInstance,
    unsigned long *time2wait
);

ttsResultType tts_API_DEFINITION ttsUnclaimLicense(
    ttsHandleType hInstance,
    unsigned long *time2wait
);

ttsResultType tts_API_DEFINITION ttsGetPromptID(
    ttsHandleType hInstance,
    unsigned long *PromptID,
    ttsBoolType bStarted
);

ttsResultType tts_API_DEFINITION ttsEnableEvent(
    ttsHandleType hInstance,
    ttsEventType evt,
    ttsBoolType bEnabled
);

ttsResultType tts_API_DEFINITION ttsSaveStatus(
    ttsHandleType hInstance
);

ttsResultType tts_API_DEFINITION ttsRecallStatus(
    ttsHandleType hInstance
);

#ifdef __SYMBIAN32__
ttsResultType ttsSetSpeedFast(
	ttsHandleType hInstance,
	int value
);
#endif

#if defined __cplusplus
} // extern "C"
#endif

#if (defined __cplusplus) && (!defined __SYMBIAN32__)

class tts_CLASS_DEFINITION CttsError {
public:
    ttsInfoStringType m_ErrorString;
    ttsResultType m_ErrorCode;
    CttsError(const char *ErrorString, ttsResultType r=tts_OK) 
    {
	m_ErrorCode = r;
	(void)strncpy(m_ErrorString,ErrorString,ttsSTRINGMAXLEN-1);
    }
};

class tts_CLASS_DEFINITION CttsSession {
private:
public:
    ttsHandleType m_hSession;
    
    CttsSession(const char *IniFile = NULL);
    ~CttsSession();
    
    void GetParam(const char * paramName, ttsInfoStringType paramValue);
    ttsBoolType TestVoice(const char *Speaker, unsigned int SampleRate, const char *coding);
    unsigned int SpeakerLanguage(const char *Speaker,ttsInfoStringType Language,ttsInfoStringType SubLanguage=NULL);
    unsigned int Query(const char *SelectedData, const char *DataConditions, char *QueryResult,unsigned int QueryResultLen = ttsSTRINGMAXLEN,ttsBoolType bRescanDisk = ttsFALSE);
    void GetDescription(const char *Speaker, ttsInfoStringType description);
};

class tts_CLASS_DEFINITION CttsInstance {
public:
    ttsHandleType m_hInstance;
    
    CttsInstance(CttsSession &session, const char *IniFile = NULL);
    CttsInstance(const char *IniFile = NULL);
    ~CttsInstance();
    void GetParam(const char * paramName, ttsInfoStringType paramValue);
    void SetParam(const char * paramName, const char * paramValue);
    void SetAudio(const char *AudioDestName, const char *AudioDeviceName, const char *coding, const void *pUser);
    void AudioFreeSpace(ttsBoolType *bFreeSpace);
    void Read(const void *Input, int InputType=TTSBUFFER, int TextCoding=TTSDEFAULT, int ReadingMode=TTSDEFAULT, int ProcessingMode=TTSNONBLOCKING);
    void Stop();
    void RegisterCallback(ttsCallbackType pCallback, void *pUser, unsigned long Type);
    void Pause();
    void Resume();
    void Skip(unsigned int Type, signed int NumeroUtterances);
    void Done();
    void GetLanguage(ttsInfoStringType Language, ttsInfoStringType SubLanguage);
    void GetActiveVoice(ttsInfoStringType Speaker, unsigned int *SampleRate, ttsInfoStringType Coding);
    unsigned int Query(const char *SelectedData, const char *DataConditions, char *QueryResult, unsigned int QueryResultLen, ttsBoolType bRescanDisk);
    void SetPitch(unsigned int value);
    void GetPitch(unsigned int *value);
    void SetSpeed(unsigned int value);
    void GetSpeed(unsigned int *value);
    void SetVolume(unsigned int volume);
    void GetVolume(unsigned int *volume);
    void SetDefaultAttributes();
    void SetSpeedRange(unsigned int minimum, unsigned int normal, unsigned int maximum);
    void SetPitchRange(unsigned int minimum, unsigned int normal, unsigned int maximum);
    void SetVolumeRange(unsigned int minimum, unsigned int normal, unsigned int maximum);
    void GetSpeedRange(unsigned int *minimum, unsigned int *normal, unsigned int *maximum);
    void GetPitchRange(unsigned int *minimum, unsigned int *normal, unsigned int *maximum);
    void GetVolumeRange(unsigned int *minimum, unsigned int *normal, unsigned int *maximum);
    void LanguageGuess(const void *Input, int InputType, int TextCoding, int ReadingMode, ttsInfoStringType GuessedLanguage);
    void ValidateXML(const void *Input, int InputType, int TextCoding);
    void SSMLConvert(const void *Input, char **Output, int InputType, int TextCoding);
    void PhoneticTranscription(const void * GraphemeString, void *PhonemeString, unsigned long *duration, int TextCoding, int ReadingMode);
    void CheckPhoneticTranscription(const char *PhoneticString);
    void GetExamples(char **buffer);
    void Inject(const char *command);
    void SetForeignLanguage(const char* SecondLanguage);
    void SetModularStructure(const char *head, const char *tail, void *source);
    void SetOutput(const char *module, ttsOutputFunctionType pfOutput, void *destination);
    void ClaimLicense(unsigned long *time2wait=NULL);
    void UnclaimLicense(unsigned long *time2wait=NULL);
    void GetPromptID(unsigned long *PromptID, ttsBoolType bStarted);
    void EnableEvent(ttsEventType evt, ttsBoolType bEnabled);
    void SaveStatus();
    void RecallStatus();
};

class tts_CLASS_DEFINITION CttsVoice {
private:
    CttsSession *m_PrivateSession;
    CttsInstance *m_PrivateInstance;
    ttsHandleType m_hInstance;
public:
    ttsHandleType m_hVoice;
    CttsInstance *GetInstance();
    CttsVoice(const char *IniFile, const char *Speaker, unsigned int SampleRate, const char *coding);
    CttsVoice(CttsInstance *instance, const char *Speaker, unsigned int SampleRate, const char *coding);
    void Read(const void *Input, int InputType=TTSBUFFER, int TextCoding=TTSDEFAULT, int ReadingMode=TTSDEFAULT, int ProcessingMode=TTSNONBLOCKING);
    ~CttsVoice();
    void Activate();
};

class tts_CLASS_DEFINITION CttsLexicon {
private:
    CttsVoice *m_PrivateVoice;
public:
    ttsHandleType m_hLexicon;

    CttsLexicon(CttsVoice *voice, const char *filename);
    ~CttsLexicon();
    void GetEntry(const char * string, ttsInfoStringType trascription);
    void AddEntry(const char * string, const char * transcription);
    void RemoveEntry(const char * string);
    void Save(const char * filename);
};
#endif /* __cplusplus & ! __SYMBIAN32__ */

#endif	/* tts_H_INCLUDED */
