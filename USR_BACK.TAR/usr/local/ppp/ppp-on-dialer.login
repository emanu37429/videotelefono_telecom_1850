#!/bin/sh
#
# This is a script for ppp service.
#
exec $CHAT $CHATFLAGS			\
	TIMEOUT		3				\
	ABORT		'\nBUSY\r'			\
	ABORT		'\nNO ANSWER\r'			\
	ABORT		'\nRINGING\r\n\r\nRINGING\r'	\
	''		'\rAT'				\
	'OK-+++\c-OK'	'ATH0'				\
	TIMEOUT		60				\
	OK		"ATDT $EXTNO $TELNO"			\
	CONNECT		''				\
	gin:	"vdc"	\
	word:	"vdc"
	
