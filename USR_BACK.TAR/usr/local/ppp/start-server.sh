#!/bin/sh

while true
do
	PPPC=`ifconfig | grep ppp0`
	APP=`ps -ef | grep DemoApp | grep -v grep`
	if [ "x" != x"$PPPC" ]; then
		if [ "x" = x"$APP" ]; then
			echo "exec..app"
			exec /usr/local/bin/DemoApp -x:2tn -p:2tn /usr/local/TUP/conftest/demo/com-server/phonerx.cfg /usr/local/TUP/conftest/demo/com-server/phonetx.cfg
		fi
	else
		if [ "x" != x"$APP" ]; then
			echo "kill app"
			killall DemoApp
		fi
	fi
	sleep 1
done
