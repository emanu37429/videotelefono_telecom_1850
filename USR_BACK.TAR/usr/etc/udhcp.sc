#!/bin/sh

# udhcpc script for LVP-1800 auto-download 

HOSTSFILE=/usr/etc/hosts
TEMPINFOFILE=/tmp/dhcpcd-"$interface".info

[ -z "$1" ] && echo "Error: should be called from udhcpc" && exit 1

if [ -f $TEMPINFOFILE ]
then
echo "deleting $TEMPINFOFILE"
rm $TEMPINFOFILE
fi

case "$1" in
	deconfig)
			/sbin/ifconfig $interface up
			;;

	renew|bound)
#			/sbin/ifconfig $interface $ip

			while /sbin/route del default gw 0.0.0.0 dev $interface
				do :
			done

			[ -n "$broadcast" ] && BROADCAST="broadcast $broadcast"
			[ -n "$subnet" ] && NETMASK="netmask $subnet"
			
			/sbin/ifconfig $interface $ip $BROADCAST $NETMASK
			
			echo $router

			if [ -n "$router" ] 
			then
				for i in $router; do
					/sbin/route add default gw $i dev $interface
				done
			fi

			echo -n > /usr/local/ppp/resolv.conf
			[ -n "$domain" ] && echo domain $domain > /usr/local/ppp/resolv.conf

			for i in $dns
			do
				echo nameserver $i >> /usr/local/ppp/resolv.conf
			done

			echo "DHCPSID="$siaddr
			echo "IPADDR="$ip

                        echo 127.0.0.1	localhost.localdomain	localhost > $HOSTSFILE
			echo $ip	lgvp	loghost>> $HOSTSFILE
			echo "creating $TEMPINFOFILE"
			echo "# information obtained by dhcp server" > $TEMPINFOFILE
			echo "INTERFACE='$interface'" >> $TEMPINFOFILE
			echo "DHCPSID=$siaddr" >> $TEMPINFOFILE
			echo "IPADDR=$ip" >> $TEMPINFOFILE
			echo "NETMASK=$subnet" >> $TEMPINFOFILE
			echo "GATEWAY=$router" >> $TEMPINFOFILE
			echo "DNS=$dns" >> $TEMPINFOFILE
			;;
esac

exit 0
